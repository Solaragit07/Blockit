/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.13-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: mysite_db
-- ------------------------------------------------------
-- Server version	10.11.13-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_log`
--

DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `blocked_site` varchar(255) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `data_usage` decimal(10,2) DEFAULT 0.00,
  `session_duration` int(11) DEFAULT 0,
  `severity` varchar(20) DEFAULT 'low',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_device_id` (`device_id`),
  KEY `idx_action` (`action`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `activity_log_ibfk_1` FOREIGN KEY (`device_id`) REFERENCES `device` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_log`
--

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` datetime NOT NULL,
  `device_name` varchar(255) DEFAULT NULL,
  `device_ip` varchar(64) DEFAULT NULL,
  `resource` varchar(512) DEFAULT NULL,
  `action` varchar(16) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_time` (`time`),
  KEY `idx_device_name` (`device_name`),
  KEY `idx_device_ip` (`device_ip`),
  KEY `idx_action` (`action`),
  KEY `idx_time_action` (`time`,`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `status` varchar(11) NOT NULL DEFAULT 'ACTIVE',
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`user_id`) USING BTREE,
  UNIQUE KEY `unique_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES
(1,'admin@gmail.com','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Administrator','ACTIVE','images.png','2025-07-27 16:48:42','2025-07-27 16:48:42'),
(2,'kaedekurinai@gmail.com','$2y$10$lkBUVyObKY94wHVriOFmEu2iHnc5sYa11fdrWQnRfYC.PZwdZgDgO','Kaede','ACTIVE',NULL,'2025-07-27 16:49:23','2025-07-27 16:49:23'),
(3,'test@test.com','$2y$10$3ufpNib8jKGvSwTykpQri.Ox578kVHlxGeMtTGbu7hlD6igROslx.','tessdadsad','ACTIVE',NULL,'2025-09-17 12:16:46','2025-10-27 10:52:59'),
(7,'juan@gmail.com','$2y$10$IXvts0VMWOgNaxdrhsjUB.BHIxXdLGlHSuNp..td1mFyi3AGKmFOq','juan Pogi','ACTIVE',NULL,'2025-10-21 07:55:05','2025-10-21 07:55:05'),
(8,'maryjoycorollo6@gmail.com','$2y$10$8IJUOD2QpoLYyMsWY/7TuecLVVZfiBm1ruqON6SZAR4ZVGSS2gPhW','MaryJoy Locading','ACTIVE',NULL,'2025-10-22 04:16:11','2025-10-22 04:16:11'),
(9,'jinmylovess@gmail.com','$2y$10$h7soVTVrSWczE9sdibhJNOl3kTfOs4mxhAo7wI/ytU.BToHBObeoi','Jin','ACTIVE',NULL,'2025-10-22 11:39:12','2025-10-22 11:39:12'),
(11,'rhialynponclara@gmail.com','$2y$10$k0VCjU1F5lbY7sx2NlaMK.3hicNOCzy/0BFZ.0O/AyR0HzfDGsbXa','Rialyn','ACTIVE',NULL,'2025-10-22 12:04:10','2025-10-22 12:04:10'),
(12,'ealamarellacamille@gmail.com','$2y$10$mP6jU6ZAyk52OQRVZc993.KXrWw.HRrzyQJozQ7HWE/EvDSy3K8O6','Marella e ala','ACTIVE',NULL,'2025-10-22 14:57:42','2025-10-22 14:57:42'),
(13,'airabaliguat24@gmail.com','$2y$10$OYywuYXqnlYq9paX4fXvYOJ7NVfMEMJnX1EEnWdU.dAm5ynBVCici','Francine Aira T. Baliguat','ACTIVE',NULL,'2025-10-22 15:29:33','2025-10-22 15:29:33'),
(14,'anethdennis76@gmail.com','$2y$10$QWyfgYwl.VFpgmUAMhUC9eH9ix0SPeY9E/VIKqPsqsgWIxjXZjVkC','Jeaneth','ACTIVE',NULL,'2025-10-22 21:54:17','2025-10-22 21:54:17'),
(15,'siz@gmail.com','$2y$10$aQ5TnZqP8rCcebJ.nVqAvueOdG6jSb9k7JY85RgniXMuhK3Hl49Ky','Siz','ACTIVE',NULL,'2025-10-23 01:40:10','2025-10-23 01:40:10'),
(16,'ednabandol112@gmail.com','$2y$10$7Gi/4eOpyquOivn52ug81u58bOBKCT0WUiozeM2tjRF.cMch0Z4nm','Edna Bandol','ACTIVE',NULL,'2025-10-23 02:43:59','2025-10-23 02:43:59'),
(17,'rickydelapena35@gmail.com','$2y$10$D5iLowRJXYEysiKLJyJ0tu9AoEN0eitw9ruHeFSDdMRvB94.PQJnS','Nardito','ACTIVE',NULL,'2025-10-23 02:48:37','2025-10-23 02:48:37'),
(18,'katejashley.evasco@lspu.edu.ph','$2y$10$eLlPe21KBkB.m.xgFgLo3.Nl3h0Dj27Fzbnd.pBVplrkqR65wq3jC','Kate Jashley','ACTIVE',NULL,'2025-10-23 03:31:35','2025-10-23 03:31:35'),
(19,'itzpeppeer@gmail.com','$2y$10$ndtAUyd85o8AK1ZUxBcyhez8kPwxfiaV/B3sNaLk5jvid/pvJKvNK','Jasmine Flores','ACTIVE',NULL,'2025-10-23 04:01:46','2025-10-23 04:01:46'),
(20,'zxcdlareg@gmail.com','$argon2id$v=19$m=65536,t=4,p=1$Qk9mUzN2TUZmcGlqZ21BSQ$B8vB9eCeUUNrfJxYjbJF7J/q7oUYDSTyrwPNSwm47Lk','qweqewqe','ACTIVE',NULL,'2025-10-23 09:41:51','2025-11-05 01:17:27'),
(21,'maryjoane.balakit@gmail.com','$2y$10$ZNwgE7UtcwQ0vQofV1DRMOLwKnVm5msyTQz2eJzTiZY9WsD4XD11W','Mary Joane B. Perper','ACTIVE',NULL,'2025-10-23 13:38:10','2025-10-23 13:38:10'),
(22,'gilbertrequitud@gmail.com','$2y$10$VfBAui.LSrFY5eq7AaQjduIsAm8xXGKnotUJql.DCU1ki4fWc1RFu','Gilbert','ACTIVE',NULL,'2025-10-23 18:02:01','2025-10-23 18:02:01'),
(23,'rosendalprincebarron@gmail.com','$2y$10$7I5rJBBoFSocbopuTzMRE.LQ/wHNsovIS4OyKvpSeDmAUC/Yivwhi','Prince Barron Rosendal','ACTIVE',NULL,'2025-10-27 10:55:11','2025-10-27 10:55:11'),
(24,'aronjerome.arocena@lspu.edu.ph','$2y$10$pi2X2rbMHCIJY2Jhqb2KhuWM11SYq.ASdVQYki5KNQGIghdpg170y','Arocena, Aron Jerome F.','ACTIVE',NULL,'2025-10-28 01:36:20','2025-10-28 01:36:20'),
(25,'sukuna@email.com','$2y$10$MC1cV.dEWQWzCqYRL0fBaOfoKI26nEhO0mMFGLYeJCrY4Zf5lb3ri','Sukuna','ACTIVE',NULL,'2025-11-04 00:30:39','2025-11-04 00:30:39'),
(26,'princebarron@gmail.com','$2y$10$CsS08o6BEeFW9gDd7A.tmO3CDnaX2Uwtb4aKFec8pY1wPoS9BDnOS','Prince Barron M. Rosendal','ACTIVE',NULL,'2025-11-04 21:46:27','2025-11-04 21:46:27'),
(27,'prince@gmail.com','$2y$10$0jy7PqcI2ZOwRyTYYZNU4OvFKchImKre93S3Q34aF860b77EbdRRa','prince barrron','ACTIVE',NULL,'2025-11-04 21:50:07','2025-11-04 21:50:07'),
(28,'carolynperez05@gmail.com','$2y$10$pVESSz44qu0zS1VTiE36EudV/9CfloN8YXtQGDnUMmyVOH3XF3GTu','Carolyn Perez','ACTIVE',NULL,'2025-11-05 05:03:30','2025-11-05 05:03:30'),
(29,'trvkxssd@testform.xyz','$2y$10$7g7LZim08Hv6O0rrqpJe1ehDkVWFoz/qFLIHCVkW5vFU53j6BHPQ2','vizmosgzwq','ACTIVE',NULL,'2025-11-07 17:57:43','2025-11-07 17:57:43'),
(30,'uwrlmnqv@testform.xyz','$2y$10$OvsHryDjiaHUqEUBX/BM5u20JtN09GySWpmjGqDBB/L1TeNXlKqEe','rulwnywpho','ACTIVE',NULL,'2025-11-10 09:46:41','2025-11-10 09:46:41'),
(31,'eehgklir@testform.xyz','$2y$10$2xyO2AynClde/ZlHPhuCheNAz2VkLQPwS4HhW/fkSJsvySoCxP.vK','nwmupvxpup','ACTIVE',NULL,'2025-11-15 11:46:59','2025-11-15 11:46:59'),
(32,'snrjrmsy@testform.xyz','$2y$10$PA1JXqQyVBxDQBFDD8S1XOqqzW/qo890B9jcOTGZv8u23Aiqj7QUa','ufrfoqkdfd','ACTIVE',NULL,'2025-11-19 17:14:32','2025-11-19 17:14:32'),
(33,'sanjuanmarjorie954@gmail.com','$2y$10$wVjFiTux774aZNRs5BslCeySHoRFD0GKjgAtpPvV71Z9eZpTlJ.l2','Kurinai','ACTIVE',NULL,'2026-01-15 02:30:56','2026-01-15 02:30:56');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `age_based_blacklist`
--

DROP TABLE IF EXISTS `age_based_blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `age_based_blacklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(255) NOT NULL,
  `min_age` int(11) NOT NULL,
  `max_age` int(11) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_domain` (`domain`),
  KEY `idx_age_range` (`min_age`,`max_age`),
  KEY `idx_category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `age_based_blacklist`
--

LOCK TABLES `age_based_blacklist` WRITE;
/*!40000 ALTER TABLE `age_based_blacklist` DISABLE KEYS */;
INSERT INTO `age_based_blacklist` VALUES
(1,'pornhub.com',1,17,'Adult Content','Adult content inappropriate for minors','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(2,'xvideos.com',1,17,'Adult Content','Adult content inappropriate for minors','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(3,'xnxx.com',1,17,'Adult Content','Adult content inappropriate for minors','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(4,'redtube.com',1,17,'Adult Content','Adult content inappropriate for minors','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(5,'youporn.com',1,17,'Adult Content','Adult content inappropriate for minors','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(6,'brazzers.com',1,17,'Adult Content','Adult content inappropriate for minors','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(7,'onlyfans.com',1,17,'Adult Content','Adult content inappropriate for minors','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(8,'chaturbate.com',1,17,'Adult Content','Adult content inappropriate for minors','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(9,'bet365.com',1,20,'Gambling','Gambling sites inappropriate for minors','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(10,'1xbet.com',1,20,'Gambling','Gambling sites inappropriate for minors','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(11,'pinnacle.com',1,20,'Gambling','Gambling sites inappropriate for minors','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(12,'draftkings.com',1,20,'Gambling','Gambling sites inappropriate for minors','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(13,'fanduel.com',1,20,'Gambling','Gambling sites inappropriate for minors','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(14,'888casino.com',1,20,'Gambling','Gambling sites inappropriate for minors','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(15,'betfair.com',1,20,'Gambling','Gambling sites inappropriate for minors','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(16,'facebook.com',1,12,'Social Media','Social media platform with age restrictions','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(17,'instagram.com',1,12,'Social Media','Social media platform with age restrictions','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(18,'tiktok.com',1,12,'Social Media','Social media platform with age restrictions','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(19,'snapchat.com',1,12,'Social Media','Social media platform with age restrictions','2025-08-22 05:05:16','2025-08-22 05:05:16');
/*!40000 ALTER TABLE `age_based_blacklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `age_based_whitelist`
--

DROP TABLE IF EXISTS `age_based_whitelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `age_based_whitelist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(255) NOT NULL,
  `min_age` int(11) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_domain` (`domain`),
  KEY `idx_min_age` (`min_age`),
  KEY `idx_category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `age_based_whitelist`
--

LOCK TABLES `age_based_whitelist` WRITE;
/*!40000 ALTER TABLE `age_based_whitelist` DISABLE KEYS */;
INSERT INTO `age_based_whitelist` VALUES
(5,'duolingo.com',8,'Educational','Language learning platform','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(8,'bbc.com',12,'News & Media','Reliable international news source','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(9,'cnn.com',12,'News & Media','International news coverage','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(10,'reuters.com',14,'News & Media','Professional news agency','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(11,'webmd.com',16,'Health & Wellness','Medical information resource','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(12,'mayoclinic.org',16,'Health & Wellness','Medical information from Mayo Clinic','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(13,'healthline.com',16,'Health & Wellness','Health information and advice','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(14,'google.com',5,'Search Engine','Primary search engine','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(15,'wikipedia.org',8,'Educational','Educational encyclopedia','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(16,'youtube.com',13,'Entertainment','Video platform with parental controls','2025-08-22 05:05:16','2025-08-22 05:05:16'),
(17,'khanacademy.org',5,'Educational','Category whitelist: accessible from age 5','2025-09-03 04:22:45','2025-09-03 04:22:45'),
(18,'coursera.org',5,'Educational','Category whitelist: accessible from age 5','2025-09-03 04:22:45','2025-09-03 04:22:45'),
(19,'edx.org',5,'Educational','Category whitelist: accessible from age 5','2025-09-03 04:22:45','2025-09-03 04:22:45'),
(20,'udemy.com',5,'Educational','Category whitelist: accessible from age 5','2025-09-03 04:22:45','2025-09-03 04:22:45'),
(21,'w3schools.com',5,'Educational','Category whitelist: accessible from age 5','2025-09-03 04:22:45','2025-09-03 04:22:45'),
(22,'tutorialspoint.com',5,'Educational','Category whitelist: accessible from age 5','2025-09-03 04:22:45','2025-09-03 04:22:45'),
(23,'academia.edu',5,'Educational','Category whitelist: accessible from age 5','2025-09-03 04:22:45','2025-09-03 04:22:45'),
(24,'quizlet.com',5,'Educational','Category whitelist: accessible from age 5','2025-09-03 04:22:45','2025-09-03 04:22:45'),
(25,'brilliant.org',5,'Educational','Category whitelist: accessible from age 5','2025-09-03 04:22:45','2025-09-03 04:22:45'),
(26,'futurelearn.com',5,'Educational','Category whitelist: accessible from age 5','2025-09-03 04:22:45','2025-09-03 04:22:45'),
(27,'skillshare.com',5,'Educational','Category whitelist: accessible from age 5','2025-09-03 04:22:45','2025-09-03 04:22:45'),
(28,'alison.com',5,'Educational','Category whitelist: accessible from age 5','2025-09-03 04:22:45','2025-09-03 04:22:45'),
(29,'codecademy.com',5,'Educational','Category whitelist: accessible from age 5','2025-09-03 04:22:45','2025-09-03 04:22:45'),
(30,'open.edu',5,'Educational','Category whitelist: accessible from age 5','2025-09-03 04:22:45','2025-09-03 04:22:45'),
(31,'wikiversity.org',5,'Educational','Category whitelist: accessible from age 5','2025-09-03 04:22:45','2025-09-03 04:22:45');
/*!40000 ALTER TABLE `age_based_whitelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `application_blocks`
--

DROP TABLE IF EXISTS `application_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `application_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) DEFAULT NULL,
  `application_name` varchar(100) NOT NULL,
  `application_category` varchar(50) DEFAULT NULL,
  `domains` text DEFAULT NULL,
  `ports` text DEFAULT NULL,
  `protocols` text DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `blocked_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `unblocked_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `block_type` varchar(50) DEFAULT 'complete',
  `duration` int(11) DEFAULT 0,
  `reason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `device_id` (`device_id`),
  KEY `status` (`status`),
  KEY `application_category` (`application_category`),
  KEY `idx_blocked_at` (`blocked_at`),
  CONSTRAINT `fk_application_blocks_device` FOREIGN KEY (`device_id`) REFERENCES `device` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_blocks`
--

LOCK TABLES `application_blocks` WRITE;
/*!40000 ALTER TABLE `application_blocks` DISABLE KEYS */;
INSERT INTO `application_blocks` VALUES
(13,NULL,'YouTube','Entertainment','youtube.com,www.youtube.com,youtu.be,googlevideo.com,ytimg.com,m.youtube.com,music.youtube.com,i.ytimg.com,i1.ytimg.com,i2.ytimg.com,i3.ytimg.com,youtube.googleapis.com,youtubei.googleapis.com,youtube-nocookie.com,yt3.ggpht.com',NULL,NULL,'active','2025-08-26 13:00:34',NULL,'2025-08-26 13:00:34','2025-09-03 04:24:19','complete',1,'Blocked via Quick Application Blocks'),
(15,12,'Facebook','Social Media','facebook.com,fb.com,fbcdn.net,instagram.com','80,443','facebook','active','2025-09-03 04:25:14',NULL,'2025-09-03 04:25:14','2025-09-03 04:25:14','complete',1,'Blocked via category: Social Media'),
(16,12,'Instagram','Social Media','instagram.com,cdninstagram.com,fbcdn.net','80,443','instagram','active','2025-09-03 04:25:26',NULL,'2025-09-03 04:25:26','2025-09-03 04:25:26','complete',1,'Blocked via category: Social Media'),
(17,12,'TikTok','Social Media','tiktok.com,musically.com,musical.ly,tiktokcdn.com','80,443','tiktok','active','2025-09-03 04:25:38',NULL,'2025-09-03 04:25:38','2025-09-03 04:25:38','complete',1,'Blocked via category: Social Media'),
(18,12,'Twitter','Social Media','twitter.com,t.co,twimg.com,x.com','80,443','twitter','active','2025-09-03 04:25:50',NULL,'2025-09-03 04:25:50','2025-09-03 04:25:50','complete',1,'Blocked via category: Social Media'),
(19,12,'Snapchat','Social Media','snapchat.com,sc-cdn.net','80,443','snapchat','active','2025-09-03 04:26:02',NULL,'2025-09-03 04:26:02','2025-09-03 04:26:02','complete',1,'Blocked via category: Social Media');
/*!40000 ALTER TABLE `application_blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `application_categories`
--

DROP TABLE IF EXISTS `application_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `application_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `color` varchar(7) DEFAULT '#007bff',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_categories`
--

LOCK TABLES `application_categories` WRITE;
/*!40000 ALTER TABLE `application_categories` DISABLE KEYS */;
INSERT INTO `application_categories` VALUES
(1,'Gaming','Gaming applications and platforms','fas fa-gamepad','#28a745',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(2,'Social Media','Social networking platforms','fas fa-users','#17a2b8',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(3,'Entertainment','Video streaming and entertainment','fas fa-play-circle','#ffc107',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(4,'Communication','Messaging and communication apps','fas fa-comments','#6f42c1',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(5,'Adult Content','Adult and mature content sites','fas fa-exclamation-triangle','#dc3545',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(6,'Gambling','Online gambling and betting sites','fas fa-dice','#fd7e14',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(7,'Educational','Educational platforms and resources','fas fa-graduation-cap','#20c997',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(8,'News & Media','News websites and media outlets','fas fa-newspaper','#6c757d',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(9,'Health & Wellness','Health and wellness resources','fas fa-heartbeat','#e83e8c',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(10,'Shopping','E-commerce and shopping sites','fas fa-shopping-cart','#fd7e14',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(11,'E-commerce','Online shopping platforms','fas fa-shopping-cart','#f39c12',1,'2025-08-24 14:09:27','2025-08-24 14:09:27'),
(12,'Education','Educational platforms and tools','fas fa-graduation-cap','#9b59b6',1,'2025-08-24 14:09:27','2025-08-24 14:09:27'),
(13,'News','News and media websites','fas fa-newspaper','#34495e',1,'2025-08-24 14:09:27','2025-08-24 14:09:27'),
(14,'File Sharing','File sharing and torrenting sites','fas fa-share-alt','#95a5a6',1,'2025-08-24 14:09:27','2025-08-24 14:09:27');
/*!40000 ALTER TABLE `application_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocked_email_throttle`
--

DROP TABLE IF EXISTS `blocked_email_throttle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `blocked_email_throttle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_key` varchar(128) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `last_sent` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_device_domain` (`device_key`,`domain`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocked_email_throttle`
--

LOCK TABLES `blocked_email_throttle` WRITE;
/*!40000 ALTER TABLE `blocked_email_throttle` DISABLE KEYS */;
INSERT INTO `blocked_email_throttle` VALUES
(1,'ip:164.92.69.230','ftp.blockit.site','2026-01-20 13:12:09'),
(2,'ip:20.240.204.2','31.97.190.181','2026-01-24 10:48:19'),
(4,'ip:139.59.62.75','31.97.190.181','2026-01-20 18:02:41'),
(5,'ip:138.246.253.24','31.97.190.181','2026-01-20 18:12:32'),
(6,'ip:167.94.138.116','31.97.190.181','2026-01-24 09:24:05'),
(7,'ip:47.98.182.3','31.97.190.181','2026-01-20 19:18:43'),
(8,'ip:170.64.235.130','31.97.190.181','2026-01-20 20:31:20'),
(9,'ip:103.120.189.68','31.97.190.181','2026-01-20 20:21:03'),
(11,'ip:185.242.226.111','31.97.190.181','2026-01-21 22:20:09'),
(12,'ip:162.216.149.232','31.97.190.181','2026-01-20 23:43:11'),
(13,'ip:60.52.4.51','31.97.190.181','2026-01-21 00:41:23'),
(14,'ip:112.124.52.14','31.97.190.181','2026-01-21 02:10:56'),
(15,'ip:2620:96:e000::c9','2a0247805e9dbb1','2026-01-21 05:59:38'),
(18,'ip:121.29.149.122','31.97.190.181','2026-01-21 12:50:16'),
(19,'ip:42.48.38.146','31.97.190.181','2026-01-21 12:53:41'),
(20,'ip:123.191.130.73','31.97.190.181','2026-01-21 12:53:46'),
(21,'ip:60.16.216.102','31.97.190.181','2026-01-21 12:59:46'),
(22,'ip:27.47.24.187','31.97.190.181','2026-01-21 12:59:52'),
(23,'ip:124.117.192.16','31.97.190.181','2026-01-21 13:03:26'),
(24,'ip:162.243.44.28','31.97.190.181','2026-01-21 15:32:51'),
(25,'ip:167.94.138.41','31.97.190.181','2026-01-21 19:57:12'),
(26,'ip:167.94.138.126','31.97.190.181','2026-01-21 20:00:13'),
(27,'ip:23.180.120.132','srv1025241.hstgr.cloud','2026-01-21 21:58:37'),
(29,'ip:209.38.89.164','31.97.190.181','2026-01-22 00:46:37'),
(31,'ip:147.185.132.229','31.97.190.181','2026-01-22 01:05:19'),
(32,'ip:2602:80d:1006::61','2a0247805e9dbb1','2026-01-22 06:55:16'),
(33,'ip:206.81.26.67','31.97.190.181','2026-01-22 09:25:25'),
(34,'ip:35.203.211.65','31.97.190.181','2026-01-22 10:07:29'),
(35,'ip:112.124.12.41','','2026-01-22 10:08:35'),
(36,'ip:112.124.12.41','31.97.190.181','2026-01-22 10:08:45'),
(38,'ip:2a06:4883:7000::7d','2a0247805e9dbb1','2026-01-22 10:35:59'),
(39,'ip:2a06:4882:9000::b5','2a0247805e9dbb1','2026-01-22 10:36:03'),
(40,'ip:2a06:4883:b000::d7','2a0247805e9dbb1','2026-01-22 10:36:04'),
(41,'ip:188.166.28.34','31.97.190.181','2026-01-22 14:18:23'),
(43,'ip:139.59.28.138','31.97.190.181','2026-01-22 17:33:59'),
(45,'ip:173.249.15.69','31.97.190.181','2026-01-22 21:03:01'),
(46,'ip:143.198.176.117','31.97.190.181','2026-01-23 01:00:47'),
(47,'ip:147.185.133.215','31.97.190.181','2026-01-23 01:44:51'),
(48,'ip:2a06:4882:b000::be','2a0247805e9dbb1','2026-01-23 04:25:54'),
(49,'ip:2a06:4883:5000::5f','2a0247805e9dbb1','2026-01-23 04:25:57'),
(50,'ip:216.180.246.33','31.97.190.181','2026-01-23 06:57:49'),
(52,'ip:2602:80d:1006::13','2a0247805e9dbb1','2026-01-23 07:53:14'),
(53,'ip:172.237.105.19','31.97.190.181','2026-01-23 10:00:25'),
(54,'ip:162.142.125.126','31.97.190.181','2026-01-23 08:40:34'),
(57,'ip:178.128.232.4','31.97.190.181','2026-01-23 12:24:12'),
(59,'ip:170.64.237.77','31.97.190.181','2026-01-23 23:42:51'),
(60,'ip:35.203.210.92','31.97.190.181','2026-01-24 03:56:04'),
(61,'ip:162.216.149.247','31.97.190.181','2026-01-24 06:41:55'),
(62,'ip:2620:96:e000::118','2a0247805e9dbb1','2026-01-24 08:53:16'),
(64,'ip:129.212.231.109','31.97.190.181','2026-01-24 10:47:35');
/*!40000 ALTER TABLE `blocked_email_throttle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocking_log`
--

DROP TABLE IF EXISTS `blocking_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `blocking_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) DEFAULT NULL,
  `blocked_domain` varchar(255) DEFAULT NULL,
  `block_reason` varchar(255) DEFAULT NULL,
  `blocked_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `device_id` (`device_id`),
  KEY `blocked_at` (`blocked_at`),
  KEY `idx_blocked_domain` (`blocked_domain`),
  CONSTRAINT `fk_blocking_log_device` FOREIGN KEY (`device_id`) REFERENCES `device` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocking_log`
--

LOCK TABLES `blocking_log` WRITE;
/*!40000 ALTER TABLE `blocking_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `blocking_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocklist`
--

DROP TABLE IF EXISTS `blocklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `blocklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `website` text DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `blocking_method` enum('drop','redirect') DEFAULT 'drop',
  `added_by` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`) USING BTREE,
  KEY `category` (`category`),
  KEY `added_by` (`added_by`),
  KEY `idx_is_active` (`is_active`),
  KEY `idx_blocking_method` (`blocking_method`)
) ENGINE=InnoDB AUTO_INCREMENT=185 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocklist`
--

LOCK TABLES `blocklist` WRITE;
/*!40000 ALTER TABLE `blocklist` DISABLE KEYS */;
INSERT INTO `blocklist` VALUES
(163,'youtube.com',NULL,NULL,'drop',NULL,1,'2025-08-26 13:00:34','2025-08-26 13:00:34'),
(164,'www.youtube.com',NULL,NULL,'drop',NULL,1,'2025-08-26 13:00:34','2025-08-26 13:00:34'),
(165,'youtu.be',NULL,NULL,'drop',NULL,1,'2025-08-26 13:00:34','2025-08-26 13:00:34'),
(168,'m.youtube.com',NULL,NULL,'drop',NULL,1,'2025-08-26 13:00:34','2025-08-26 13:00:34'),
(169,'music.youtube.com',NULL,NULL,'drop',NULL,1,'2025-08-26 13:00:34','2025-08-26 13:00:34'),
(170,'i.ytimg.com',NULL,NULL,'drop',NULL,1,'2025-08-26 13:00:34','2025-08-26 13:00:34'),
(171,'i1.ytimg.com',NULL,NULL,'drop',NULL,1,'2025-08-26 13:00:34','2025-08-26 13:00:34'),
(172,'i2.ytimg.com',NULL,NULL,'drop',NULL,1,'2025-08-26 13:00:34','2025-08-26 13:00:34'),
(173,'i3.ytimg.com',NULL,NULL,'drop',NULL,1,'2025-08-26 13:00:34','2025-08-26 13:00:34'),
(174,'youtube.googleapis.com',NULL,NULL,'drop',NULL,1,'2025-08-26 13:00:34','2025-08-26 13:00:34'),
(175,'youtubei.googleapis.com',NULL,NULL,'drop',NULL,1,'2025-08-26 13:00:34','2025-08-26 13:00:34'),
(176,'youtube-nocookie.com',NULL,NULL,'drop',NULL,1,'2025-08-26 13:00:34','2025-08-26 13:00:34'),
(177,'yt3.ggpht.com',NULL,NULL,'drop',NULL,1,'2025-08-26 13:00:34','2025-08-26 13:00:34');
/*!40000 ALTER TABLE `blocklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `color` varchar(7) DEFAULT '#007bff',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `unique_category_name` (`category_name`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES
(1,'Social Media','Social networking and communication platforms','fas fa-users','#3b5998',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(2,'Entertainment','Video streaming and entertainment content','fas fa-play','#ff0000',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(3,'Gaming','Online games and gaming platforms','fas fa-gamepad','#00ff00',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(4,'Adult Content','Adult and mature content websites','fas fa-exclamation-triangle','#dc3545',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(5,'Gambling','Online gambling and betting sites','fas fa-dice','#ffc107',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(6,'Shopping','E-commerce and shopping websites','fas fa-shopping-cart','#17a2b8',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(7,'News','News and media websites','fas fa-newspaper','#6c757d',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(8,'Educational','Educational and learning platforms','fas fa-graduation-cap','#28a745',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(9,'Health','Health and medical websites','fas fa-heartbeat','#e83e8c',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(10,'Communication','Messaging and communication apps','fas fa-comments','#6f42c1',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(11,'Productivity','Work and productivity tools','fas fa-briefcase','#fd7e14',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(12,'Other','Miscellaneous websites','fas fa-globe','#6c757d',1,'2025-07-27 16:48:42','2025-07-27 16:48:42');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device`
--

DROP TABLE IF EXISTS `device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `device` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_name` varchar(255) DEFAULT NULL,
  `mac_address` varchar(17) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `device_type` varchar(50) DEFAULT NULL,
  `status` enum('active','inactive','blocked') DEFAULT 'active',
  `timelimit` int(11) DEFAULT 24,
  `blocked_until` datetime DEFAULT NULL,
  `bandwidth` int(11) DEFAULT 1,
  `internet` varchar(10) DEFAULT 'No',
  `last_seen` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `name` varchar(255) NOT NULL DEFAULT '',
  `age` int(11) DEFAULT NULL,
  `device` varchar(100) DEFAULT 'Smartphone',
  `image` varchar(255) DEFAULT 'default_avatar.png',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `mac_address` (`mac_address`),
  KEY `status` (`status`),
  KEY `last_seen` (`last_seen`),
  KEY `idx_ip_address` (`ip_address`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device`
--

LOCK TABLES `device` WRITE;
/*!40000 ALTER TABLE `device` DISABLE KEYS */;
INSERT INTO `device` VALUES
(10,NULL,'9A:C1:84:DA:8F:22',NULL,NULL,'active',2,NULL,1,'No','2025-08-22 07:39:19','2025-08-22 07:39:19','2025-08-22 07:39:19','Kaede',8,'Smartphone','default_avatar.png'),
(11,NULL,'16:8A:F7:D7:C5:0C',NULL,NULL,'active',2,NULL,1,'No','2025-08-24 15:49:44','2025-08-24 15:49:44','2025-08-24 15:49:44','jeann',13,'Smartphone','default_avatar.png'),
(12,NULL,'8A:7D:53:86:9F:3B',NULL,NULL,'active',1,NULL,1,'No','2025-08-24 16:19:15','2025-08-24 16:19:15','2025-08-24 16:19:15','Berto',4,'Smartphone','default_avatar.png');
/*!40000 ALTER TABLE `device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_block_log`
--

DROP TABLE IF EXISTS `device_block_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_block_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mac_address` varchar(17) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `blocked_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `actions_taken` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mac` (`mac_address`),
  KEY `idx_blocked_at` (`blocked_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_block_log`
--

LOCK TABLES `device_block_log` WRITE;
/*!40000 ALTER TABLE `device_block_log` DISABLE KEYS */;
INSERT INTO `device_block_log` VALUES
(1,'9A:C1:84:DA:8F:22','time_limit_exceeded','2025-08-24 16:54:45','[\"Database error: Unknown column \'blocked_reason\' in \'field list\'\",\"Added firewall rule to block device on router\",\"Removed DHCP lease for device\",\"Ended active device session\"]');
/*!40000 ALTER TABLE `device_block_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_profiles`
--

DROP TABLE IF EXISTS `device_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mac_address` varchar(17) NOT NULL,
  `device_name` varchar(255) NOT NULL,
  `ip_address` varchar(15) DEFAULT NULL,
  `status` enum('active','inactive','blocked') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `mac_address` (`mac_address`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_profiles`
--

LOCK TABLES `device_profiles` WRITE;
/*!40000 ALTER TABLE `device_profiles` DISABLE KEYS */;
INSERT INTO `device_profiles` VALUES
(1,'9A:C1:84:DA:8F:22','Kaede','192.168.10.254','active','2025-08-22 06:52:42','2025-08-22 07:39:19'),
(3,'16:8A:F7:D7:C5:0C','jeann','192.168.10.252','active','2025-08-24 15:49:44','2025-08-24 15:49:44'),
(4,'8A:7D:53:86:9F:3B','Berto','192.168.10.251','active','2025-08-24 16:19:15','2025-08-24 16:19:15');
/*!40000 ALTER TABLE `device_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_sessions`
--

DROP TABLE IF EXISTS `device_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) DEFAULT NULL,
  `mac_address` varchar(17) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `session_start` timestamp NOT NULL DEFAULT current_timestamp(),
  `session_end` timestamp NULL DEFAULT NULL,
  `status` enum('active','ended','blocked') DEFAULT 'active',
  `data_usage` bigint(20) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `mac_address` (`mac_address`),
  KEY `device_id` (`device_id`),
  KEY `session_start` (`session_start`),
  KEY `status` (`status`),
  CONSTRAINT `fk_device_sessions_device` FOREIGN KEY (`device_id`) REFERENCES `device` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_sessions`
--

LOCK TABLES `device_sessions` WRITE;
/*!40000 ALTER TABLE `device_sessions` DISABLE KEYS */;
INSERT INTO `device_sessions` VALUES
(1,NULL,'1A:BB:A2:09:C3:8E',NULL,'2025-07-27 18:13:43','2025-07-28 02:13:55','active',0,'2025-07-28 00:13:43','2025-07-28 02:13:55'),
(2,NULL,'16:F5:63:81:30:B6',NULL,'2025-07-27 19:00:03','2025-07-27 20:27:29','active',0,'2025-07-28 01:00:03','2025-07-28 02:27:29'),
(3,NULL,'42:43:E9:8A:0F:BF',NULL,'2025-07-27 20:13:32','2025-07-27 20:27:29','active',0,'2025-07-28 02:13:32','2025-07-28 02:27:30'),
(4,NULL,'42:43:E9:8A:0F:BF',NULL,'2025-07-27 20:32:34','2025-07-27 21:19:21','active',0,'2025-07-28 02:32:34','2025-07-28 03:19:21'),
(5,NULL,'16:F5:63:81:30:B6',NULL,'2025-07-27 20:33:29','2025-07-27 21:19:21','active',0,'2025-07-28 02:33:29','2025-07-28 03:19:21'),
(6,NULL,'16:F5:63:81:30:B6',NULL,'2025-08-15 18:36:26',NULL,'active',0,'2025-08-16 00:36:26','2025-08-16 00:36:26'),
(7,NULL,'42:43:E9:8A:0F:BF',NULL,'2025-08-15 18:36:26',NULL,'active',0,'2025-08-16 00:36:26','2025-08-16 00:36:26'),
(8,NULL,'1A:BB:A2:09:C3:8E',NULL,'2025-08-16 01:02:22',NULL,'active',0,'2025-08-16 07:02:22','2025-08-16 07:02:22'),
(9,NULL,'F8:75:A4:34:9F:69',NULL,'2025-08-18 07:11:27',NULL,'active',0,'2025-08-18 13:11:27','2025-08-18 13:11:27'),
(10,NULL,'F8:75:A4:34:9F:69',NULL,'2025-08-19 04:30:31',NULL,'active',0,'2025-08-19 10:30:31','2025-08-19 10:30:31'),
(11,NULL,'02:00:00:00:00:01',NULL,'2025-08-20 00:00:00',NULL,'active',0,'2025-08-20 15:48:39','2025-08-20 15:48:39'),
(12,NULL,'02:00:00:00:00:02',NULL,'2025-08-20 01:30:00',NULL,'active',0,'2025-08-20 15:48:39','2025-08-20 15:48:39'),
(13,NULL,'02:00:00:00:00:03',NULL,'2025-08-20 01:45:00',NULL,'active',0,'2025-08-20 15:48:39','2025-08-20 15:48:39'),
(14,NULL,'16:8A:F7:D7:C5:0C',NULL,'2025-08-20 19:29:32',NULL,'active',0,'2025-08-21 01:29:32','2025-08-21 01:29:32'),
(15,NULL,'16:F5:63:81:30:B6',NULL,'2025-08-20 19:29:32',NULL,'active',0,'2025-08-21 01:29:32','2025-08-21 01:29:32'),
(16,NULL,'02:00:00:00:00:01',NULL,'2025-08-20 19:30:06',NULL,'active',0,'2025-08-21 01:30:06','2025-08-21 01:30:06'),
(17,NULL,'02:00:00:00:00:02',NULL,'2025-08-20 19:30:06',NULL,'active',0,'2025-08-21 01:30:06','2025-08-21 01:30:06'),
(18,NULL,'02:00:00:00:00:03',NULL,'2025-08-20 19:30:06',NULL,'active',0,'2025-08-21 01:30:06','2025-08-21 01:30:06'),
(19,NULL,'9A:C1:84:DA:8F:22',NULL,'2025-08-20 19:50:37','2025-08-24 16:54:45','active',0,'2025-08-21 01:50:37','2025-08-24 16:54:45'),
(20,NULL,'9A:C1:84:DA:8F:22',NULL,'2025-08-21 22:19:55','2025-08-24 16:54:45','active',0,'2025-08-22 04:19:55','2025-08-24 16:54:45'),
(21,NULL,'16:F5:63:81:30:B6',NULL,'2025-08-21 22:49:13',NULL,'active',0,'2025-08-22 04:49:13','2025-08-22 04:49:13');
/*!40000 ALTER TABLE `device_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_time_limits`
--

DROP TABLE IF EXISTS `device_time_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_time_limits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mac_address` varchar(17) NOT NULL,
  `hostname` varchar(255) DEFAULT NULL,
  `time_limit_minutes` int(11) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_mac_active` (`mac_address`,`is_active`),
  KEY `idx_end_time` (`end_time`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_time_limits`
--

LOCK TABLES `device_time_limits` WRITE;
/*!40000 ALTER TABLE `device_time_limits` DISABLE KEYS */;
INSERT INTO `device_time_limits` VALUES
(1,'56:60:45:D3:BE:32','Unknown Device',60,'2025-08-20 09:33:32','2025-08-20 10:33:32',1,'2025-08-20 09:33:32','2025-08-20 09:33:32'),
(2,'10:63:C8:78:48:FB','LAPTOP-L0M4FMSM',30,'2025-08-20 14:52:04','2025-08-20 15:22:04',1,'2025-08-20 09:33:38','2025-08-20 14:52:04'),
(3,'00:11:22:33:44:57','MockDevice-Error',30,'2025-08-20 15:36:05','2025-08-20 16:06:05',1,'2025-08-20 15:35:57','2025-08-20 15:36:05'),
(4,'9A:C1:84:DA:8F:22','Kaede',1,'2025-08-22 10:54:16','2025-08-22 10:55:16',0,'2025-08-22 09:03:12','2025-08-24 16:52:33'),
(5,'00:11:22:33:44:55','test-device',5,'2025-08-22 09:20:00','2025-08-22 09:25:00',1,'2025-08-22 09:21:22','2025-08-22 09:21:22'),
(6,'02:00:00:00:00:01','iPhone-Test',5,'2025-08-22 09:20:00','2025-08-22 09:25:00',1,'2025-08-22 09:48:14','2025-08-22 09:48:14'),
(7,'8A:7D:53:86:9F:3B','Berto',60,'2025-08-24 18:19:15','2025-08-24 19:19:15',1,'2025-08-24 16:19:15','2025-08-24 16:19:15'),
(8,'9A:C1:84:DA:8F:22','Kaede',61,'2025-08-24 16:52:23','2025-08-24 17:53:23',0,'2025-08-24 16:52:33','2025-08-25 07:49:22'),
(9,'42:43:E9:8A:0F:BF','Redmi-Note-11E',60,'2025-08-25 07:15:36','2025-08-25 08:15:36',1,'2025-08-25 07:15:36','2025-08-25 07:15:36'),
(10,'9A:C1:84:DA:8F:22','Kaede',60,'2025-08-25 07:49:22','2025-08-25 08:49:22',1,'2025-08-25 07:49:22','2025-08-25 07:49:22');
/*!40000 ALTER TABLE `device_time_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ecommerce_platforms`
--

DROP TABLE IF EXISTS `ecommerce_platforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ecommerce_platforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `url` varchar(255) NOT NULL,
  `access` enum('browsing','full','blocked') NOT NULL DEFAULT 'browsing',
  `reason` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ecommerce_platforms`
--

LOCK TABLES `ecommerce_platforms` WRITE;
/*!40000 ALTER TABLE `ecommerce_platforms` DISABLE KEYS */;
INSERT INTO `ecommerce_platforms` VALUES
(2,'Amazon','amazon.com','browsing','','2025-08-24 15:29:21'),
(3,'eBay','ebay.com','browsing','','2025-08-24 15:29:21'),
(4,'Shopee','shopee.ph','browsing','','2025-08-24 15:29:21'),
(6,'SHEIN','shein.com','browsing','','2025-08-24 15:29:21'),
(7,'Tiktok','tiktok.com','browsing','','2025-08-24 16:22:13');
/*!40000 ALTER TABLE `ecommerce_platforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ecommerce_settings`
--

DROP TABLE IF EXISTS `ecommerce_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ecommerce_settings` (
  `id` tinyint(4) NOT NULL DEFAULT 1,
  `block_access` tinyint(1) NOT NULL DEFAULT 0,
  `block_purchases` tinyint(1) NOT NULL DEFAULT 0,
  `notifications` tinyint(1) NOT NULL DEFAULT 0,
  `notification_methods` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`notification_methods`)),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ecommerce_settings`
--

LOCK TABLES `ecommerce_settings` WRITE;
/*!40000 ALTER TABLE `ecommerce_settings` DISABLE KEYS */;
INSERT INTO `ecommerce_settings` VALUES
(1,0,1,1,'[\"email\"]','2025-08-24 16:22:22');
/*!40000 ALTER TABLE `ecommerce_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_block`
--

DROP TABLE IF EXISTS `group_block`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_block` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` text DEFAULT NULL,
  `website` text DEFAULT NULL,
  `from_age` varchar(255) DEFAULT NULL,
  `to_age` varchar(255) DEFAULT NULL,
  `block_type` enum('permanent','scheduled','time_based') DEFAULT 'permanent',
  `schedule_start` time DEFAULT NULL,
  `schedule_end` time DEFAULT NULL,
  `blocking_method` enum('drop','redirect') DEFAULT 'drop',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`) USING BTREE,
  KEY `category` (`category`(100)),
  KEY `from_age` (`from_age`),
  KEY `to_age` (`to_age`),
  KEY `idx_is_active` (`is_active`),
  KEY `idx_blocking_method` (`blocking_method`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_block`
--

LOCK TABLES `group_block` WRITE;
/*!40000 ALTER TABLE `group_block` DISABLE KEYS */;
INSERT INTO `group_block` VALUES
(1,'Adult Content','pornhub.com','1','17','permanent',NULL,NULL,'drop',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(2,'Adult Content','xvideos.com','1','17','permanent',NULL,NULL,'drop',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(3,'Adult Content','xnxx.com','1','17','permanent',NULL,NULL,'drop',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(4,'Adult Content','redtube.com','1','17','permanent',NULL,NULL,'drop',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(5,'Adult Content','youporn.com','1','17','permanent',NULL,NULL,'drop',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(6,'Adult Content','brazzers.com','1','17','permanent',NULL,NULL,'drop',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(7,'Adult Content','onlyfans.com','1','17','permanent',NULL,NULL,'drop',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(8,'Adult Content','chaturbate.com','1','17','permanent',NULL,NULL,'drop',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(9,'Gambling','bet365.com','1','17','permanent',NULL,NULL,'drop',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(10,'Gambling','1xbet.com','1','17','permanent',NULL,NULL,'drop',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(11,'Gambling','pinnacle.com','1','17','permanent',NULL,NULL,'drop',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(12,'Gambling','draftkings.com','1','17','permanent',NULL,NULL,'drop',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(13,'Gambling','fanduel.com','1','17','permanent',NULL,NULL,'drop',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(14,'Gambling','888casino.com','1','17','permanent',NULL,NULL,'drop',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(15,'Gambling','betfair.com','1','17','permanent',NULL,NULL,'drop',1,'2025-07-27 16:48:42','2025-07-27 16:48:42');
/*!40000 ALTER TABLE `group_block` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_whitelist`
--

DROP TABLE IF EXISTS `group_whitelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_whitelist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) DEFAULT NULL,
  `website` text DEFAULT NULL,
  `from_age` varchar(255) DEFAULT NULL,
  `to_age` varchar(255) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`) USING BTREE,
  KEY `category` (`category`),
  KEY `from_age` (`from_age`),
  KEY `to_age` (`to_age`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_whitelist`
--

LOCK TABLES `group_whitelist` WRITE;
/*!40000 ALTER TABLE `group_whitelist` DISABLE KEYS */;
INSERT INTO `group_whitelist` VALUES
(8,'News & Media','bbc.com','12','30','Reliable news source',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(9,'News & Media','cnn.com','12','30','International news',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(10,'Health & Wellness','webmd.com','16','30','Health information',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(11,'Entertainment','netflix.com','4','8',NULL,1,'2025-08-22 06:02:10','2025-08-22 06:02:10'),
(12,'Entertainment','disney.com','4','8',NULL,1,'2025-08-22 06:02:10','2025-08-22 06:02:10'),
(13,'Entertainment','hulu.com','4','8',NULL,1,'2025-08-22 06:02:10','2025-08-22 06:02:10'),
(14,'Entertainment','amazonprime.com','4','8',NULL,1,'2025-08-22 06:02:10','2025-08-22 06:02:10'),
(15,'Entertainment','hbo.com','4','8',NULL,1,'2025-08-22 06:02:10','2025-08-22 06:02:10'),
(16,'Entertainment','spotify.com','4','8',NULL,1,'2025-08-22 06:02:10','2025-08-22 06:02:10'),
(17,'Entertainment','apple.com/music','4','8',NULL,1,'2025-08-22 06:02:10','2025-08-22 06:02:10'),
(18,'Entertainment','pandora.com','4','8',NULL,1,'2025-08-22 06:02:10','2025-08-22 06:02:10'),
(19,'Entertainment','soundcloud.com','4','8',NULL,1,'2025-08-22 06:02:10','2025-08-22 06:02:10'),
(20,'Entertainment','imdb.com','4','8',NULL,1,'2025-08-22 06:02:10','2025-08-22 06:02:10'),
(21,'Entertainment','rottentomatoes.com','4','8',NULL,1,'2025-08-22 06:02:10','2025-08-22 06:02:10'),
(22,'Entertainment','moviefone.com','4','8',NULL,1,'2025-08-22 06:02:10','2025-08-22 06:02:10'),
(23,'Entertainment','entertainment.com','4','8',NULL,1,'2025-08-22 06:02:10','2025-08-22 06:02:10'),
(24,'Entertainment','variety.com','4','8',NULL,1,'2025-08-22 06:02:10','2025-08-22 06:02:10'),
(25,'Entertainment','eonline.com','4','8',NULL,1,'2025-08-22 06:02:10','2025-08-22 06:02:10'),
(26,'Educational','khanacademy.org','5','10',NULL,1,'2025-09-03 04:22:45','2025-09-03 04:22:45'),
(27,'Educational','coursera.org','5','10',NULL,1,'2025-09-03 04:22:45','2025-09-03 04:22:45'),
(28,'Educational','edx.org','5','10',NULL,1,'2025-09-03 04:22:45','2025-09-03 04:22:45'),
(29,'Educational','udemy.com','5','10',NULL,1,'2025-09-03 04:22:45','2025-09-03 04:22:45'),
(30,'Educational','w3schools.com','5','10',NULL,1,'2025-09-03 04:22:45','2025-09-03 04:22:45'),
(31,'Educational','tutorialspoint.com','5','10',NULL,1,'2025-09-03 04:22:45','2025-09-03 04:22:45'),
(32,'Educational','academia.edu','5','10',NULL,1,'2025-09-03 04:22:45','2025-09-03 04:22:45'),
(33,'Educational','quizlet.com','5','10',NULL,1,'2025-09-03 04:22:45','2025-09-03 04:22:45'),
(34,'Educational','brilliant.org','5','10',NULL,1,'2025-09-03 04:22:45','2025-09-03 04:22:45'),
(35,'Educational','futurelearn.com','5','10',NULL,1,'2025-09-03 04:22:45','2025-09-03 04:22:45'),
(36,'Educational','skillshare.com','5','10',NULL,1,'2025-09-03 04:22:45','2025-09-03 04:22:45'),
(37,'Educational','alison.com','5','10',NULL,1,'2025-09-03 04:22:45','2025-09-03 04:22:45'),
(38,'Educational','codecademy.com','5','10',NULL,1,'2025-09-03 04:22:45','2025-09-03 04:22:45'),
(39,'Educational','open.edu','5','10',NULL,1,'2025-09-03 04:22:45','2025-09-03 04:22:45'),
(40,'Educational','wikiversity.org','5','10',NULL,1,'2025-09-03 04:22:45','2025-09-03 04:22:45');
/*!40000 ALTER TABLE `group_whitelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `device_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `action` enum('blocked','allowed','redirected') DEFAULT 'blocked',
  `reason` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`) USING BTREE,
  KEY `device_id` (`device_id`),
  KEY `action` (`action`),
  KEY `date` (`date`),
  KEY `idx_domain` (`domain`)
) ENGINE=InnoDB AUTO_INCREMENT=359 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
INSERT INTO `logs` VALUES
(1,'blocked','31.97.190.181',NULL,'20.240.204.2','Python/3.11 aiohttp/3.8.4','blocked','dns_redirect','2026-01-16 11:48:34','2026-01-16 11:48:34','2026-01-16 11:48:34'),
(2,'blocked','antrean.logammulia.com',NULL,'197.234.240.69','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1','blocked','dns_redirect','2026-01-16 12:18:00','2026-01-16 12:18:00','2026-01-16 12:18:00'),
(3,'blocked','31.97.190.181',NULL,'185.242.226.111','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36','blocked','dns_redirect','2026-01-16 12:53:48','2026-01-16 12:53:48','2026-01-16 12:53:48'),
(4,'blocked','31.97.190.181',NULL,'20.240.204.2','Python/3.11 aiohttp/3.8.4','blocked','dns_redirect','2026-01-16 13:16:57','2026-01-16 13:16:57','2026-01-16 13:16:57'),
(5,'blocked','31.97.190.181',NULL,'185.242.226.111','Python/3.7 aiohttp/3.8.1','blocked','dns_redirect','2026-01-16 13:31:31','2026-01-16 13:31:31','2026-01-16 13:31:31'),
(6,'blocked','31.97.190.181',NULL,'185.242.226.111','Python/3.7 aiohttp/3.8.1','blocked','dns_redirect','2026-01-16 13:31:38','2026-01-16 13:31:38','2026-01-16 13:31:38'),
(7,'blocked','31.97.190.181',NULL,'103.120.189.68','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15','blocked','dns_redirect','2026-01-16 15:29:27','2026-01-16 15:29:27','2026-01-16 15:29:27'),
(8,'blocked','31.97.190.181',NULL,'103.120.189.68','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0','blocked','dns_redirect','2026-01-16 15:29:27','2026-01-16 15:29:27','2026-01-16 15:29:27'),
(9,'blocked','2a0247805e9dbb1',NULL,'2a06:4882:9000::92','Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)','blocked','dns_redirect','2026-01-16 15:42:03','2026-01-16 15:42:03','2026-01-16 15:42:03'),
(10,'blocked','antrean.logammulia.com',NULL,'1.1.1.1','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1','blocked','dns_redirect','2026-01-16 17:03:55','2026-01-16 17:03:55','2026-01-16 17:03:55'),
(11,'blocked','31.97.190.181',NULL,'34.86.239.201','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.197 Safari/537.36','blocked','dns_redirect','2026-01-16 19:27:04','2026-01-16 19:27:04','2026-01-16 19:27:04'),
(12,'blocked','31.97.190.181',NULL,'82.223.68.204','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36 Assetnote/1.0.0','blocked','dns_redirect','2026-01-16 20:57:55','2026-01-16 20:57:55','2026-01-16 20:57:55'),
(13,'blocked','31.97.190.181',NULL,'82.223.68.204','python-requests/2.27.1','blocked','dns_redirect','2026-01-16 20:57:56','2026-01-16 20:57:56','2026-01-16 20:57:56'),
(14,'blocked','31.97.190.181',NULL,'35.203.210.228','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','blocked','dns_redirect','2026-01-16 23:59:10','2026-01-16 23:59:10','2026-01-16 23:59:10'),
(15,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1000::44','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 01:55:50','2026-01-17 01:55:50','2026-01-17 01:55:50'),
(16,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::2e','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 01:55:55','2026-01-17 01:55:55','2026-01-17 01:55:55'),
(17,'blocked','2a0247805e9dbb1',NULL,'2620:96:e000::101','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 01:56:06','2026-01-17 01:56:06','2026-01-17 01:56:06'),
(18,'blocked','2a0247805e9dbb1',NULL,'2620:96:e000::dc','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 01:56:10','2026-01-17 01:56:10','2026-01-17 01:56:10'),
(19,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::13','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 01:56:15','2026-01-17 01:56:15','2026-01-17 01:56:15'),
(20,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1000::45','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 01:56:27','2026-01-17 01:56:27','2026-01-17 01:56:27'),
(21,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::29','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 01:56:32','2026-01-17 01:56:32','2026-01-17 01:56:32'),
(22,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::6b','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 01:56:39','2026-01-17 01:56:39','2026-01-17 01:56:39'),
(23,'blocked','2a0247805e9dbb1',NULL,'2620:96:e000::100','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 01:56:39','2026-01-17 01:56:39','2026-01-17 01:56:39'),
(24,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1000::11','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 01:56:51','2026-01-17 01:56:51','2026-01-17 01:56:51'),
(25,'blocked','2a0247805e9dbb1',NULL,'2620:96:e000::106','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 01:56:53','2026-01-17 01:56:53','2026-01-17 01:56:53'),
(26,'blocked','2a0247805e9dbb1',NULL,'2620:96:e000::cd','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 01:57:00','2026-01-17 01:57:00','2026-01-17 01:57:00'),
(27,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1000::39','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 01:57:19','2026-01-17 01:57:19','2026-01-17 01:57:19'),
(28,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::47','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 01:57:22','2026-01-17 01:57:22','2026-01-17 01:57:22'),
(29,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1000::40','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 01:57:56','2026-01-17 01:57:56','2026-01-17 01:57:56'),
(30,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::6e','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 01:58:09','2026-01-17 01:58:09','2026-01-17 01:58:09'),
(31,'blocked','2a0247805e9dbb1',NULL,'2620:96:e000::b5','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 01:58:38','2026-01-17 01:58:38','2026-01-17 01:58:38'),
(32,'blocked','2a0247805e9dbb1',NULL,'2620:96:e000::b4','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 01:58:50','2026-01-17 01:58:50','2026-01-17 01:58:50'),
(33,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1000::4a','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 01:59:06','2026-01-17 01:59:06','2026-01-17 01:59:06'),
(34,'blocked','2a0247805e9dbb1',NULL,'2620:96:e000::b4','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 02:01:16','2026-01-17 02:01:16','2026-01-17 02:01:16'),
(35,'blocked','31.97.190.181',NULL,'162.243.70.62','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-17 02:21:13','2026-01-17 02:21:13','2026-01-17 02:21:13'),
(36,'blocked','31.97.190.181',NULL,'162.243.70.62','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-17 02:21:14','2026-01-17 02:21:14','2026-01-17 02:21:14'),
(37,'blocked','31.97.190.181',NULL,'162.243.70.62','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-17 02:21:16','2026-01-17 02:21:16','2026-01-17 02:21:16'),
(38,'blocked','31.97.190.181',NULL,'162.243.70.62','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-17 02:21:17','2026-01-17 02:21:17','2026-01-17 02:21:17'),
(39,'blocked','31.97.190.181',NULL,'147.185.133.186','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','blocked','dns_redirect','2026-01-17 03:32:46','2026-01-17 03:32:46','2026-01-17 03:32:46'),
(40,'blocked','',NULL,'121.41.164.122','','blocked','dns_redirect','2026-01-17 06:53:09','2026-01-17 06:53:09','2026-01-17 06:53:09'),
(41,'blocked','31.97.190.181',NULL,'121.41.164.122','Mozilla/5.0 (compatible; Nmap Scripting Engine; https://nmap.org/book/nse.html)','blocked','dns_redirect','2026-01-17 06:53:16','2026-01-17 06:53:16','2026-01-17 06:53:16'),
(42,'blocked','31.97.190.181',NULL,'121.41.164.122','Mozilla/5.0 (compatible; Nmap Scripting Engine; https://nmap.org/book/nse.html)','blocked','dns_redirect','2026-01-17 06:53:16','2026-01-17 06:53:16','2026-01-17 06:53:16'),
(43,'blocked','31.97.190.181',NULL,'121.41.164.122','Mozilla/5.0 (compatible; Nmap Scripting Engine; https://nmap.org/book/nse.html)','blocked','dns_redirect','2026-01-17 06:53:17','2026-01-17 06:53:17','2026-01-17 06:53:17'),
(44,'blocked','31.97.190.181',NULL,'121.41.164.122','Mozilla/5.0 (compatible; Nmap Scripting Engine; https://nmap.org/book/nse.html)','blocked','dns_redirect','2026-01-17 06:53:17','2026-01-17 06:53:17','2026-01-17 06:53:17'),
(45,'blocked','',NULL,'121.41.164.122','','blocked','dns_redirect','2026-01-17 06:53:37','2026-01-17 06:53:37','2026-01-17 06:53:37'),
(46,'blocked','31.97.190.181',NULL,'121.41.164.122','','blocked','dns_redirect','2026-01-17 06:53:38','2026-01-17 06:53:38','2026-01-17 06:53:38'),
(47,'blocked','antrean.logammulia.com',NULL,'127.0.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1','blocked','dns_redirect','2026-01-17 07:10:12','2026-01-17 07:10:12','2026-01-17 07:10:12'),
(48,'blocked','31.97.190.181',NULL,'23.94.162.106','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.85 Safari/537.36 Edg/90.0.818.46','blocked','dns_redirect','2026-01-17 08:13:57','2026-01-17 08:13:57','2026-01-17 08:13:57'),
(49,'blocked','31.97.190.181',NULL,'142.93.192.173','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/118.0','blocked','dns_redirect','2026-01-17 09:30:06','2026-01-17 09:30:06','2026-01-17 09:30:06'),
(50,'blocked','31.97.190.181',NULL,'162.142.125.41','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 09:54:31','2026-01-17 09:54:31','2026-01-17 09:54:31'),
(51,'blocked','31.97.190.181',NULL,'167.94.138.162','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 09:56:19','2026-01-17 09:56:19','2026-01-17 09:56:19'),
(52,'blocked','31.97.190.181',NULL,'162.142.125.41','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-17 09:57:34','2026-01-17 09:57:34','2026-01-17 09:57:34'),
(53,'blocked','31.97.190.181',NULL,'20.240.204.2','Python/3.11 aiohttp/3.8.4','blocked','dns_redirect','2026-01-17 11:12:17','2026-01-17 11:12:17','2026-01-17 11:12:17'),
(54,'blocked','31.97.190.181',NULL,'180.94.150.50','','blocked','dns_redirect','2026-01-17 12:57:18','2026-01-17 12:57:18','2026-01-17 12:57:18'),
(55,'blocked','31.97.190.181',NULL,'175.19.74.72','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36','blocked','dns_redirect','2026-01-17 13:14:29','2026-01-17 13:14:29','2026-01-17 13:14:29'),
(56,'blocked','31.97.190.181',NULL,'185.242.226.111','Python/3.7 aiohttp/3.8.1','blocked','dns_redirect','2026-01-17 16:27:12','2026-01-17 16:27:12','2026-01-17 16:27:12'),
(57,'blocked','31.97.190.181',NULL,'185.242.226.111','Python/3.7 aiohttp/3.8.1','blocked','dns_redirect','2026-01-17 16:27:15','2026-01-17 16:27:15','2026-01-17 16:27:15'),
(58,'blocked','31.97.190.181',NULL,'20.240.204.2','Python/3.11 aiohttp/3.8.4','blocked','dns_redirect','2026-01-17 17:16:00','2026-01-17 17:16:00','2026-01-17 17:16:00'),
(59,'blocked','31.97.190.181',NULL,'208.68.38.152','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-17 22:01:25','2026-01-17 22:01:25','2026-01-17 22:01:25'),
(60,'blocked','31.97.190.181',NULL,'208.68.38.152','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-17 22:01:26','2026-01-17 22:01:26','2026-01-17 22:01:26'),
(61,'blocked','31.97.190.181',NULL,'208.68.38.152','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-17 22:01:28','2026-01-17 22:01:28','2026-01-17 22:01:28'),
(62,'blocked','31.97.190.181',NULL,'208.68.38.152','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-17 22:01:30','2026-01-17 22:01:30','2026-01-17 22:01:30'),
(63,'blocked','31.97.190.181',NULL,'137.184.100.54','Mozilla/5.0 (X11; Linux x86_64; rv:1.9.6.20) Gecko/ Firefox/3.6.3','blocked','dns_redirect','2026-01-17 23:23:40','2026-01-17 23:23:40','2026-01-17 23:23:40'),
(64,'blocked','31.97.190.181',NULL,'35.203.210.56','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','blocked','dns_redirect','2026-01-18 01:14:24','2026-01-18 01:14:24','2026-01-18 01:14:24'),
(65,'blocked','2a0247805e9dbb1',NULL,'2620:96:e000::10d','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-18 03:00:43','2026-01-18 03:00:43','2026-01-18 03:00:43'),
(66,'blocked','2a0247805e9dbb1',NULL,'2620:96:e000::10d','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-18 03:01:28','2026-01-18 03:01:28','2026-01-18 03:01:28'),
(67,'blocked','31.97.190.181',NULL,'165.227.198.7','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36; ClaudeBot/1.0; +claudebot@anthropic.com)','blocked','dns_redirect','2026-01-18 06:32:12','2026-01-18 06:32:12','2026-01-18 06:32:12'),
(68,'blocked','31.97.190.181',NULL,'167.71.48.101','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-18 09:05:38','2026-01-18 09:05:38','2026-01-18 09:05:38'),
(69,'blocked','31.97.190.181',NULL,'167.71.48.101','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-18 09:05:39','2026-01-18 09:05:39','2026-01-18 09:05:39'),
(70,'blocked','31.97.190.181',NULL,'167.71.48.101','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-18 09:05:41','2026-01-18 09:05:41','2026-01-18 09:05:41'),
(71,'blocked','31.97.190.181',NULL,'167.71.48.101','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-18 09:05:42','2026-01-18 09:05:42','2026-01-18 09:05:42'),
(72,'blocked','31.97.190.181',NULL,'167.94.138.162','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-18 09:39:27','2026-01-18 09:39:27','2026-01-18 09:39:27'),
(73,'blocked','31.97.190.181',NULL,'167.94.138.162','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-18 09:39:51','2026-01-18 09:39:51','2026-01-18 09:39:51'),
(74,'blocked','31.97.190.181',NULL,'35.203.211.172','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','blocked','dns_redirect','2026-01-18 10:10:50','2026-01-18 10:10:50','2026-01-18 10:10:50'),
(75,'blocked','31.97.190.181',NULL,'146.190.216.39','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:134.0) Gecko/20100101 Firefox/134.0','blocked','dns_redirect','2026-01-18 10:17:42','2026-01-18 10:17:42','2026-01-18 10:17:42'),
(76,'blocked','31.97.190.181',NULL,'146.190.216.39','Mozilla/5.0 (X11; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0','blocked','dns_redirect','2026-01-18 10:17:43','2026-01-18 10:17:43','2026-01-18 10:17:43'),
(77,'blocked','31.97.190.181',NULL,'146.190.216.39','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:133.0) Gecko/20100101 Firefox/133.0','blocked','dns_redirect','2026-01-18 10:17:43','2026-01-18 10:17:43','2026-01-18 10:17:43'),
(78,'blocked','31.97.190.181',NULL,'134.199.160.85','Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0','blocked','dns_redirect','2026-01-18 11:05:27','2026-01-18 11:05:27','2026-01-18 11:05:27'),
(79,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:30','2026-01-18 11:05:30','2026-01-18 11:05:30'),
(80,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:31','2026-01-18 11:05:31','2026-01-18 11:05:31'),
(81,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:31','2026-01-18 11:05:31','2026-01-18 11:05:31'),
(82,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:32','2026-01-18 11:05:32','2026-01-18 11:05:32'),
(83,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:32','2026-01-18 11:05:32','2026-01-18 11:05:32'),
(84,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:32','2026-01-18 11:05:32','2026-01-18 11:05:32'),
(85,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:32','2026-01-18 11:05:32','2026-01-18 11:05:32'),
(86,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:33','2026-01-18 11:05:33','2026-01-18 11:05:33'),
(87,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:33','2026-01-18 11:05:33','2026-01-18 11:05:33'),
(88,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:33','2026-01-18 11:05:33','2026-01-18 11:05:33'),
(89,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:34','2026-01-18 11:05:34','2026-01-18 11:05:34'),
(90,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:34','2026-01-18 11:05:34','2026-01-18 11:05:34'),
(91,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:34','2026-01-18 11:05:34','2026-01-18 11:05:34'),
(92,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:35','2026-01-18 11:05:35','2026-01-18 11:05:35'),
(93,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:35','2026-01-18 11:05:35','2026-01-18 11:05:35'),
(94,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:36','2026-01-18 11:05:36','2026-01-18 11:05:36'),
(95,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:36','2026-01-18 11:05:36','2026-01-18 11:05:36'),
(96,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:36','2026-01-18 11:05:36','2026-01-18 11:05:36'),
(97,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:37','2026-01-18 11:05:37','2026-01-18 11:05:37'),
(98,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:37','2026-01-18 11:05:37','2026-01-18 11:05:37'),
(99,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:37','2026-01-18 11:05:37','2026-01-18 11:05:37'),
(100,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:38','2026-01-18 11:05:38','2026-01-18 11:05:38'),
(101,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:38','2026-01-18 11:05:38','2026-01-18 11:05:38'),
(102,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:38','2026-01-18 11:05:38','2026-01-18 11:05:38'),
(103,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:39','2026-01-18 11:05:39','2026-01-18 11:05:39'),
(104,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:39','2026-01-18 11:05:39','2026-01-18 11:05:39'),
(105,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:39','2026-01-18 11:05:39','2026-01-18 11:05:39'),
(106,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:40','2026-01-18 11:05:40','2026-01-18 11:05:40'),
(107,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:40','2026-01-18 11:05:40','2026-01-18 11:05:40'),
(108,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:40','2026-01-18 11:05:40','2026-01-18 11:05:40'),
(109,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:41','2026-01-18 11:05:41','2026-01-18 11:05:41'),
(110,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:41','2026-01-18 11:05:41','2026-01-18 11:05:41'),
(111,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:41','2026-01-18 11:05:41','2026-01-18 11:05:41'),
(112,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:42','2026-01-18 11:05:42','2026-01-18 11:05:42'),
(113,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:42','2026-01-18 11:05:42','2026-01-18 11:05:42'),
(114,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:42','2026-01-18 11:05:42','2026-01-18 11:05:42'),
(115,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:43','2026-01-18 11:05:43','2026-01-18 11:05:43'),
(116,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:43','2026-01-18 11:05:43','2026-01-18 11:05:43'),
(117,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:43','2026-01-18 11:05:43','2026-01-18 11:05:43'),
(118,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:44','2026-01-18 11:05:44','2026-01-18 11:05:44'),
(119,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:44','2026-01-18 11:05:44','2026-01-18 11:05:44'),
(120,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:44','2026-01-18 11:05:44','2026-01-18 11:05:44'),
(121,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:45','2026-01-18 11:05:45','2026-01-18 11:05:45'),
(122,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:45','2026-01-18 11:05:45','2026-01-18 11:05:45'),
(123,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:45','2026-01-18 11:05:45','2026-01-18 11:05:45'),
(124,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:46','2026-01-18 11:05:46','2026-01-18 11:05:46'),
(125,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:46','2026-01-18 11:05:46','2026-01-18 11:05:46'),
(126,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:46','2026-01-18 11:05:46','2026-01-18 11:05:46'),
(127,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:47','2026-01-18 11:05:47','2026-01-18 11:05:47'),
(128,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:47','2026-01-18 11:05:47','2026-01-18 11:05:47'),
(129,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:47','2026-01-18 11:05:47','2026-01-18 11:05:47'),
(130,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:48','2026-01-18 11:05:48','2026-01-18 11:05:48'),
(131,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:48','2026-01-18 11:05:48','2026-01-18 11:05:48'),
(132,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:48','2026-01-18 11:05:48','2026-01-18 11:05:48'),
(133,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:49','2026-01-18 11:05:49','2026-01-18 11:05:49'),
(134,'blocked','31.97.190.181',NULL,'134.199.160.85','python-httpx/0.28.1','blocked','dns_redirect','2026-01-18 11:05:49','2026-01-18 11:05:49','2026-01-18 11:05:49'),
(135,'blocked','31.97.190.181',NULL,'20.240.204.2','Python/3.11 aiohttp/3.8.4','blocked','dns_redirect','2026-01-18 12:02:33','2026-01-18 12:02:33','2026-01-18 12:02:33'),
(136,'blocked','31.97.190.181',NULL,'20.240.204.2','Python/3.11 aiohttp/3.8.4','blocked','dns_redirect','2026-01-18 13:03:06','2026-01-18 13:03:06','2026-01-18 13:03:06'),
(137,'blocked','31.97.190.181',NULL,'162.216.150.58','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','blocked','dns_redirect','2026-01-18 13:17:59','2026-01-18 13:17:59','2026-01-18 13:17:59'),
(138,'blocked','31.97.190.181',NULL,'185.242.226.111','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36','blocked','dns_redirect','2026-01-18 17:43:13','2026-01-18 17:43:13','2026-01-18 17:43:13'),
(139,'blocked','2a0247805e9dbb',NULL,'2001:4ca0:108:42::24','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.134 Safari/537.36','blocked','dns_redirect','2026-01-18 18:34:57','2026-01-18 18:34:57','2026-01-18 18:34:57'),
(140,'blocked','31.97.190.181',NULL,'170.64.129.6','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-18 20:18:06','2026-01-18 20:18:06','2026-01-18 20:18:06'),
(141,'blocked','31.97.190.181',NULL,'170.64.129.6','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-18 20:18:08','2026-01-18 20:18:08','2026-01-18 20:18:08'),
(142,'blocked','31.97.190.181',NULL,'170.64.129.6','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-18 20:18:08','2026-01-18 20:18:08','2026-01-18 20:18:08'),
(143,'blocked','31.97.190.181',NULL,'170.64.129.6','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-18 20:18:09','2026-01-18 20:18:09','2026-01-18 20:18:09'),
(144,'blocked','31.97.190.181',NULL,'103.120.189.68','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15','blocked','dns_redirect','2026-01-18 22:45:49','2026-01-18 22:45:49','2026-01-18 22:45:49'),
(145,'blocked','31.97.190.181',NULL,'103.120.189.68','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0','blocked','dns_redirect','2026-01-18 22:45:49','2026-01-18 22:45:49','2026-01-18 22:45:49'),
(146,'blocked','31.97.190.181',NULL,'104.152.222.104','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15','blocked','dns_redirect','2026-01-18 23:59:08','2026-01-18 23:59:08','2026-01-18 23:59:08'),
(147,'blocked','31.97.190.181',NULL,'104.152.222.104','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15','blocked','dns_redirect','2026-01-18 23:59:08','2026-01-18 23:59:08','2026-01-18 23:59:08'),
(148,'blocked','31.97.190.181',NULL,'216.126.225.168','python-requests/2.32.5','blocked','dns_redirect','2026-01-19 00:31:10','2026-01-19 00:31:10','2026-01-19 00:31:10'),
(149,'blocked','31.97.190.181',NULL,'45.55.229.20','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-19 01:26:39','2026-01-19 01:26:39','2026-01-19 01:26:39'),
(150,'blocked','31.97.190.181',NULL,'45.55.229.20','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-19 01:26:46','2026-01-19 01:26:46','2026-01-19 01:26:46'),
(151,'blocked','31.97.190.181',NULL,'147.185.132.202','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','blocked','dns_redirect','2026-01-19 01:50:37','2026-01-19 01:50:37','2026-01-19 01:50:37'),
(152,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::69','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-19 03:51:50','2026-01-19 03:51:50','2026-01-19 03:51:50'),
(153,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::69','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-19 03:58:51','2026-01-19 03:58:51','2026-01-19 03:58:51'),
(154,'blocked','31.97.190.181',NULL,'198.211.106.106','Mozilla/5.0 (ZZ; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-19 05:48:00','2026-01-19 05:48:00','2026-01-19 05:48:00'),
(155,'blocked','31.97.190.181',NULL,'198.211.106.106','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-19 05:48:01','2026-01-19 05:48:01','2026-01-19 05:48:01'),
(156,'blocked','31.97.190.181',NULL,'198.211.106.106','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/603.3.8 (KHTML, like Gecko) Version/10.1.2 Safari/603.3.8','blocked','dns_redirect','2026-01-19 05:48:01','2026-01-19 05:48:01','2026-01-19 05:48:01'),
(157,'blocked','31.97.190.181',NULL,'198.211.106.106','Mozilla/5.0 (Macintosh; Intel Mac OS X 13_5_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Safari/605.1.15','blocked','dns_redirect','2026-01-19 05:48:02','2026-01-19 05:48:02','2026-01-19 05:48:02'),
(158,'blocked','31.97.190.181',NULL,'52.139.176.136','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-19 06:47:42','2026-01-19 06:47:42','2026-01-19 06:47:42'),
(159,'blocked','2a0247805e9dbb1',NULL,'2a06:4883:5000::4b','Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)','blocked','dns_redirect','2026-01-19 07:11:27','2026-01-19 07:11:27','2026-01-19 07:11:27'),
(160,'blocked','31.97.190.181',NULL,'167.71.128.248','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-19 08:21:47','2026-01-19 08:21:47','2026-01-19 08:21:47'),
(161,'blocked','31.97.190.181',NULL,'167.71.128.248','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-19 08:21:49','2026-01-19 08:21:49','2026-01-19 08:21:49'),
(162,'blocked','31.97.190.181',NULL,'167.71.128.248','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-19 08:21:50','2026-01-19 08:21:50','2026-01-19 08:21:50'),
(163,'blocked','31.97.190.181',NULL,'167.71.128.248','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-19 08:21:52','2026-01-19 08:21:52','2026-01-19 08:21:52'),
(164,'blocked','31.97.190.181',NULL,'67.205.179.67','Mozilla/5.0 (Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-19 08:32:53','2026-01-19 08:32:53','2026-01-19 08:32:53'),
(165,'blocked','31.97.190.181',NULL,'67.205.179.67','Mozilla/5.0 (Kubuntu; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-19 08:32:54','2026-01-19 08:32:54','2026-01-19 08:32:54'),
(166,'blocked','31.97.190.181',NULL,'67.205.179.67','Mozilla/5.0 (X11; Linux x86_64; rv:133.0) Gecko/20100101 Firefox/133.0','blocked','dns_redirect','2026-01-19 08:32:55','2026-01-19 08:32:55','2026-01-19 08:32:55'),
(167,'blocked','31.97.190.181',NULL,'67.205.179.67','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:73.0) Gecko/20100101 Firefox/73.0','blocked','dns_redirect','2026-01-19 08:32:56','2026-01-19 08:32:56','2026-01-19 08:32:56'),
(168,'blocked','31.97.190.181',NULL,'167.94.138.38','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-19 09:58:20','2026-01-19 09:58:20','2026-01-19 09:58:20'),
(169,'blocked','',NULL,'2607:8500:faca:de::133','','blocked','dns_redirect','2026-01-19 10:20:29','2026-01-19 10:20:29','2026-01-19 10:20:29'),
(170,'blocked','srv1025241.hstgr.cloud',NULL,'2607:8500:faca:de::133','Mozilla/5.0 (compatible; Nmap Scripting Engine; https://nmap.org/book/nse.html)','blocked','dns_redirect','2026-01-19 10:20:30','2026-01-19 10:20:30','2026-01-19 10:20:30'),
(171,'blocked','srv1025241.hstgr.cloud',NULL,'2607:8500:faca:de::133','Mozilla/5.0 (compatible; Nmap Scripting Engine; https://nmap.org/book/nse.html)','blocked','dns_redirect','2026-01-19 10:20:30','2026-01-19 10:20:30','2026-01-19 10:20:30'),
(172,'blocked','srv1025241.hstgr.cloud',NULL,'2607:8500:faca:de::133','Mozilla/5.0 (compatible; Nmap Scripting Engine; https://nmap.org/book/nse.html)','blocked','dns_redirect','2026-01-19 10:20:31','2026-01-19 10:20:31','2026-01-19 10:20:31'),
(173,'blocked','srv1025241.hstgr.cloud',NULL,'2607:8500:faca:de::133','Mozilla/5.0 (compatible; Nmap Scripting Engine; https://nmap.org/book/nse.html)','blocked','dns_redirect','2026-01-19 10:20:31','2026-01-19 10:20:31','2026-01-19 10:20:31'),
(174,'blocked','',NULL,'2607:8500:faca:de::133','','blocked','dns_redirect','2026-01-19 10:20:32','2026-01-19 10:20:32','2026-01-19 10:20:32'),
(175,'blocked','srv1025241.hstgr.cloud',NULL,'2607:8500:faca:de::133','','blocked','dns_redirect','2026-01-19 10:20:33','2026-01-19 10:20:33','2026-01-19 10:20:33'),
(176,'blocked','31.97.190.181',NULL,'113.161.74.86','','blocked','dns_redirect','2026-01-19 12:20:37','2026-01-19 12:20:37','2026-01-19 12:20:37'),
(177,'blocked','31.97.190.181',NULL,'20.240.204.2','Python/3.11 aiohttp/3.8.4','blocked','dns_redirect','2026-01-19 14:03:38','2026-01-19 14:03:38','2026-01-19 14:03:38'),
(178,'blocked','31.97.190.181',NULL,'20.240.204.2','Python/3.11 aiohttp/3.8.4','blocked','dns_redirect','2026-01-19 14:25:41','2026-01-19 14:25:41','2026-01-19 14:25:41'),
(179,'blocked','31.97.190.181',NULL,'138.68.145.43','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-19 18:33:50','2026-01-19 18:33:50','2026-01-19 18:33:50'),
(180,'blocked','31.97.190.181',NULL,'138.68.145.43','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-19 18:33:51','2026-01-19 18:33:51','2026-01-19 18:33:51'),
(181,'blocked','31.97.190.181',NULL,'138.68.145.43','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-19 18:33:53','2026-01-19 18:33:53','2026-01-19 18:33:53'),
(182,'blocked','31.97.190.181',NULL,'138.68.145.43','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-19 18:33:54','2026-01-19 18:33:54','2026-01-19 18:33:54'),
(183,'blocked','31.97.190.181',NULL,'185.242.226.111','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36','blocked','dns_redirect','2026-01-19 20:36:46','2026-01-19 20:36:46','2026-01-19 20:36:46'),
(184,'blocked','2a0247805e9dbb1',NULL,'2a06:4882:b000::c0','Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)','blocked','dns_redirect','2026-01-19 21:57:16','2026-01-19 21:57:16','2026-01-19 21:57:16'),
(185,'blocked','31.97.190.181',NULL,'162.216.150.56','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','blocked','dns_redirect','2026-01-19 23:21:21','2026-01-19 23:21:21','2026-01-19 23:21:21'),
(186,'blocked','31.97.190.181',NULL,'103.120.189.68','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-20 00:43:07','2026-01-20 00:43:07','2026-01-20 00:43:07'),
(187,'blocked','31.97.190.181',NULL,'103.120.189.68','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-20 00:43:07','2026-01-20 00:43:07','2026-01-20 00:43:07'),
(188,'blocked','31.97.190.181',NULL,'138.68.174.29','Mozilla/5.0 (X11; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0','blocked','dns_redirect','2026-01-20 00:44:33','2026-01-20 00:44:33','2026-01-20 00:44:33'),
(189,'blocked','31.97.190.181',NULL,'138.68.174.29','Mozilla/5.0 (X11; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0','blocked','dns_redirect','2026-01-20 00:44:37','2026-01-20 00:44:37','2026-01-20 00:44:37'),
(190,'blocked','31.97.190.181',NULL,'170.64.220.148','Mozilla/5.0','blocked','dns_redirect','2026-01-20 03:37:22','2026-01-20 03:37:22','2026-01-20 03:37:22'),
(191,'blocked','31.97.190.181',NULL,'170.64.220.148','Mozilla/5.0','blocked','dns_redirect','2026-01-20 03:37:23','2026-01-20 03:37:23','2026-01-20 03:37:23'),
(192,'blocked','2a0247805e9dbb1',NULL,'2620:96:e000::10a','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-20 04:51:35','2026-01-20 04:51:35','2026-01-20 04:51:35'),
(193,'blocked','2a0247805e9dbb1',NULL,'2620:96:e000::10a','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-20 04:53:27','2026-01-20 04:53:27','2026-01-20 04:53:27'),
(194,'blocked','31.97.190.181',NULL,'134.199.169.17','Mozilla/5.0','blocked','dns_redirect','2026-01-20 08:27:14','2026-01-20 08:27:14','2026-01-20 08:27:14'),
(195,'blocked','31.97.190.181',NULL,'134.199.169.17','Mozilla/5.0','blocked','dns_redirect','2026-01-20 08:27:14','2026-01-20 08:27:14','2026-01-20 08:27:14'),
(196,'blocked','31.97.190.181',NULL,'185.242.226.102','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36','blocked','dns_redirect','2026-01-20 08:45:49','2026-01-20 08:45:49','2026-01-20 08:45:49'),
(197,'blocked','31.97.190.181',NULL,'35.203.211.173','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','blocked','dns_redirect','2026-01-20 10:57:33','2026-01-20 10:57:33','2026-01-20 10:57:33'),
(198,'blocked','facebook.com',NULL,'192.168.88.50','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','blocked','blocked-site','2026-01-20 12:27:47','2026-01-20 12:27:47','2026-01-20 12:27:47'),
(199,'blocked','facebook.com',NULL,'192.168.88.50','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','blocked','blocked-site','2026-01-20 12:27:51','2026-01-20 12:27:51','2026-01-20 12:27:51'),
(200,'blocked','ftp.blockit.site',NULL,'164.92.69.230','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-20 13:12:05','2026-01-20 13:12:05','2026-01-20 13:12:05'),
(201,'blocked','31.97.190.181',NULL,'20.240.204.2','Python/3.11 aiohttp/3.8.4','blocked','dns_redirect','2026-01-20 17:34:11','2026-01-20 17:34:11','2026-01-20 17:34:11'),
(202,'blocked','31.97.190.181',NULL,'20.240.204.2','Python/3.11 aiohttp/3.8.4','blocked','dns_redirect','2026-01-20 17:49:49','2026-01-20 17:49:49','2026-01-20 17:49:49'),
(203,'blocked','31.97.190.181',NULL,'139.59.62.75','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-20 18:02:39','2026-01-20 18:02:39','2026-01-20 18:02:39'),
(204,'blocked','31.97.190.181',NULL,'139.59.62.75','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-20 18:02:42','2026-01-20 18:02:42','2026-01-20 18:02:42'),
(205,'blocked','31.97.190.181',NULL,'139.59.62.75','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-20 18:02:43','2026-01-20 18:02:43','2026-01-20 18:02:43'),
(206,'blocked','31.97.190.181',NULL,'139.59.62.75','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-20 18:02:44','2026-01-20 18:02:44','2026-01-20 18:02:44'),
(207,'blocked','31.97.190.181',NULL,'138.246.253.24','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.134 Safari/537.36','blocked','dns_redirect','2026-01-20 18:12:29','2026-01-20 18:12:29','2026-01-20 18:12:29'),
(208,'blocked','31.97.190.181',NULL,'167.94.138.116','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-20 18:50:50','2026-01-20 18:50:50','2026-01-20 18:50:50'),
(209,'blocked','31.97.190.181',NULL,'167.94.138.116','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-20 18:50:58','2026-01-20 18:50:58','2026-01-20 18:50:58'),
(210,'blocked','31.97.190.181',NULL,'167.94.138.116','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-20 18:51:01','2026-01-20 18:51:01','2026-01-20 18:51:01'),
(211,'blocked','31.97.190.181',NULL,'167.94.138.116','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-20 18:52:18','2026-01-20 18:52:18','2026-01-20 18:52:18'),
(212,'blocked','31.97.190.181',NULL,'167.94.138.116','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-20 18:52:25','2026-01-20 18:52:25','2026-01-20 18:52:25'),
(213,'blocked','31.97.190.181',NULL,'167.94.138.116','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-20 18:52:33','2026-01-20 18:52:33','2026-01-20 18:52:33'),
(214,'blocked','31.97.190.181',NULL,'47.98.182.3','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36','blocked','dns_redirect','2026-01-20 19:18:39','2026-01-20 19:18:39','2026-01-20 19:18:39'),
(215,'blocked','31.97.190.181',NULL,'47.98.182.3','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36','blocked','dns_redirect','2026-01-20 19:18:43','2026-01-20 19:18:43','2026-01-20 19:18:43'),
(216,'blocked','31.97.190.181',NULL,'47.98.182.3','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36','blocked','dns_redirect','2026-01-20 19:18:44','2026-01-20 19:18:44','2026-01-20 19:18:44'),
(217,'blocked','31.97.190.181',NULL,'170.64.235.130','Mozilla/5.0','blocked','dns_redirect','2026-01-20 19:55:23','2026-01-20 19:55:23','2026-01-20 19:55:23'),
(218,'blocked','31.97.190.181',NULL,'170.64.235.130','Mozilla/5.0','blocked','dns_redirect','2026-01-20 19:55:26','2026-01-20 19:55:26','2026-01-20 19:55:26'),
(219,'blocked','31.97.190.181',NULL,'103.120.189.68','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-20 20:21:00','2026-01-20 20:21:00','2026-01-20 20:21:00'),
(220,'blocked','31.97.190.181',NULL,'103.120.189.68','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0','blocked','dns_redirect','2026-01-20 20:21:03','2026-01-20 20:21:03','2026-01-20 20:21:03'),
(221,'blocked','31.97.190.181',NULL,'170.64.235.130','Mozilla/5.0','blocked','dns_redirect','2026-01-20 20:31:17','2026-01-20 20:31:17','2026-01-20 20:31:17'),
(222,'blocked','31.97.190.181',NULL,'170.64.235.130','Mozilla/5.0','blocked','dns_redirect','2026-01-20 20:31:21','2026-01-20 20:31:21','2026-01-20 20:31:21'),
(223,'blocked','31.97.190.181',NULL,'185.242.226.111','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36','blocked','dns_redirect','2026-01-20 21:26:02','2026-01-20 21:26:02','2026-01-20 21:26:02'),
(224,'blocked','31.97.190.181',NULL,'162.216.149.232','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','blocked','dns_redirect','2026-01-20 23:43:08','2026-01-20 23:43:08','2026-01-20 23:43:08'),
(225,'blocked','31.97.190.181',NULL,'60.52.4.51','','blocked','dns_redirect','2026-01-21 00:41:20','2026-01-21 00:41:20','2026-01-21 00:41:20'),
(226,'blocked','31.97.190.181',NULL,'112.124.52.14','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36','blocked','dns_redirect','2026-01-21 02:10:53','2026-01-21 02:10:53','2026-01-21 02:10:53'),
(227,'blocked','31.97.190.181',NULL,'112.124.52.14','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36','blocked','dns_redirect','2026-01-21 02:10:56','2026-01-21 02:10:56','2026-01-21 02:10:56'),
(228,'blocked','31.97.190.181',NULL,'112.124.52.14','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36','blocked','dns_redirect','2026-01-21 02:10:57','2026-01-21 02:10:57','2026-01-21 02:10:57'),
(229,'blocked','2a0247805e9dbb1',NULL,'2620:96:e000::c9','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-21 05:59:35','2026-01-21 05:59:35','2026-01-21 05:59:35'),
(230,'blocked','31.97.190.181',NULL,'20.240.204.2','Python/3.11 aiohttp/3.8.4','blocked','dns_redirect','2026-01-21 11:57:28','2026-01-21 11:57:28','2026-01-21 11:57:28'),
(231,'blocked','31.97.190.181',NULL,'20.240.204.2','Python/3.11 aiohttp/3.8.4','blocked','dns_redirect','2026-01-21 12:10:47','2026-01-21 12:10:47','2026-01-21 12:10:47'),
(232,'blocked','31.97.190.181',NULL,'121.29.149.122','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36','blocked','dns_redirect','2026-01-21 12:50:13','2026-01-21 12:50:13','2026-01-21 12:50:13'),
(233,'blocked','31.97.190.181',NULL,'42.48.38.146','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36','blocked','dns_redirect','2026-01-21 12:53:39','2026-01-21 12:53:39','2026-01-21 12:53:39'),
(234,'blocked','31.97.190.181',NULL,'123.191.130.73','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36','blocked','dns_redirect','2026-01-21 12:53:43','2026-01-21 12:53:43','2026-01-21 12:53:43'),
(235,'blocked','31.97.190.181',NULL,'60.16.216.102','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36','blocked','dns_redirect','2026-01-21 12:59:44','2026-01-21 12:59:44','2026-01-21 12:59:44'),
(236,'blocked','31.97.190.181',NULL,'27.47.24.187','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36','blocked','dns_redirect','2026-01-21 12:59:49','2026-01-21 12:59:49','2026-01-21 12:59:49'),
(237,'blocked','31.97.190.181',NULL,'124.117.192.16','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36','blocked','dns_redirect','2026-01-21 13:03:24','2026-01-21 13:03:24','2026-01-21 13:03:24'),
(238,'blocked','31.97.190.181',NULL,'162.243.44.28','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-21 15:32:48','2026-01-21 15:32:48','2026-01-21 15:32:48'),
(239,'blocked','31.97.190.181',NULL,'162.243.44.28','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-21 15:32:53','2026-01-21 15:32:53','2026-01-21 15:32:53'),
(240,'blocked','31.97.190.181',NULL,'162.243.44.28','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-21 15:32:54','2026-01-21 15:32:54','2026-01-21 15:32:54'),
(241,'blocked','31.97.190.181',NULL,'162.243.44.28','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-21 15:32:55','2026-01-21 15:32:55','2026-01-21 15:32:55'),
(242,'blocked','31.97.190.181',NULL,'167.94.138.41','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-21 19:57:09','2026-01-21 19:57:09','2026-01-21 19:57:09'),
(243,'blocked','31.97.190.181',NULL,'167.94.138.41','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-21 19:57:21','2026-01-21 19:57:21','2026-01-21 19:57:21'),
(244,'blocked','31.97.190.181',NULL,'167.94.138.41','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-21 19:57:28','2026-01-21 19:57:28','2026-01-21 19:57:28'),
(245,'blocked','31.97.190.181',NULL,'167.94.138.41','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-21 19:57:34','2026-01-21 19:57:34','2026-01-21 19:57:34'),
(246,'blocked','31.97.190.181',NULL,'167.94.138.41','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-21 19:57:41','2026-01-21 19:57:41','2026-01-21 19:57:41'),
(247,'blocked','31.97.190.181',NULL,'167.94.138.41','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-21 19:57:48','2026-01-21 19:57:48','2026-01-21 19:57:48'),
(248,'blocked','31.97.190.181',NULL,'167.94.138.126','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-21 20:00:10','2026-01-21 20:00:10','2026-01-21 20:00:10'),
(249,'blocked','31.97.190.181',NULL,'167.94.138.126','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-21 20:00:23','2026-01-21 20:00:23','2026-01-21 20:00:23'),
(250,'blocked','31.97.190.181',NULL,'167.94.138.126','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-21 20:00:28','2026-01-21 20:00:28','2026-01-21 20:00:28'),
(251,'blocked','31.97.190.181',NULL,'167.94.138.126','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-21 20:03:43','2026-01-21 20:03:43','2026-01-21 20:03:43'),
(252,'blocked','31.97.190.181',NULL,'167.94.138.126','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-21 20:03:53','2026-01-21 20:03:53','2026-01-21 20:03:53'),
(253,'blocked','31.97.190.181',NULL,'167.94.138.126','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-21 20:04:06','2026-01-21 20:04:06','2026-01-21 20:04:06'),
(254,'blocked','31.97.190.181',NULL,'167.94.138.126','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-21 20:04:19','2026-01-21 20:04:19','2026-01-21 20:04:19'),
(255,'blocked','srv1025241.hstgr.cloud',NULL,'23.180.120.132','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/122.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-21 21:58:34','2026-01-21 21:58:34','2026-01-21 21:58:34'),
(256,'blocked','31.97.190.181',NULL,'185.242.226.111','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36','blocked','dns_redirect','2026-01-21 22:20:07','2026-01-21 22:20:07','2026-01-21 22:20:07'),
(257,'blocked','31.97.190.181',NULL,'209.38.89.164','Mozilla/5.0','blocked','dns_redirect','2026-01-22 00:00:33','2026-01-22 00:00:33','2026-01-22 00:00:33'),
(258,'blocked','31.97.190.181',NULL,'209.38.89.164','Mozilla/5.0','blocked','dns_redirect','2026-01-22 00:00:36','2026-01-22 00:00:36','2026-01-22 00:00:36'),
(259,'blocked','31.97.190.181',NULL,'209.38.89.164','Mozilla/5.0','blocked','dns_redirect','2026-01-22 00:46:34','2026-01-22 00:46:34','2026-01-22 00:46:34'),
(260,'blocked','31.97.190.181',NULL,'209.38.89.164','Mozilla/5.0','blocked','dns_redirect','2026-01-22 00:46:37','2026-01-22 00:46:37','2026-01-22 00:46:37'),
(261,'blocked','31.97.190.181',NULL,'147.185.132.229','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','blocked','dns_redirect','2026-01-22 01:05:16','2026-01-22 01:05:16','2026-01-22 01:05:16'),
(262,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::61','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-22 06:55:13','2026-01-22 06:55:13','2026-01-22 06:55:13'),
(263,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::61','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-22 06:55:20','2026-01-22 06:55:20','2026-01-22 06:55:20'),
(264,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::61','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-22 06:55:21','2026-01-22 06:55:21','2026-01-22 06:55:21'),
(265,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::61','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-22 06:55:49','2026-01-22 06:55:49','2026-01-22 06:55:49'),
(266,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::61','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-22 06:55:53','2026-01-22 06:55:53','2026-01-22 06:55:53'),
(267,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::61','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-22 06:55:55','2026-01-22 06:55:55','2026-01-22 06:55:55'),
(268,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::61','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-22 06:55:56','2026-01-22 06:55:56','2026-01-22 06:55:56'),
(269,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::61','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-22 06:55:58','2026-01-22 06:55:58','2026-01-22 06:55:58'),
(270,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::61','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-22 06:55:59','2026-01-22 06:55:59','2026-01-22 06:55:59'),
(271,'blocked','31.97.190.181',NULL,'206.81.26.67','Mozilla/5.0 (X11; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0','blocked','dns_redirect','2026-01-22 09:25:22','2026-01-22 09:25:22','2026-01-22 09:25:22'),
(272,'blocked','31.97.190.181',NULL,'35.203.211.65','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','blocked','dns_redirect','2026-01-22 10:07:26','2026-01-22 10:07:26','2026-01-22 10:07:26'),
(273,'blocked','',NULL,'112.124.12.41','','blocked','dns_redirect','2026-01-22 10:08:33','2026-01-22 10:08:33','2026-01-22 10:08:33'),
(274,'blocked','31.97.190.181',NULL,'112.124.12.41','Mozilla/5.0 (compatible; Nmap Scripting Engine; https://nmap.org/book/nse.html)','blocked','dns_redirect','2026-01-22 10:08:42','2026-01-22 10:08:42','2026-01-22 10:08:42'),
(275,'blocked','31.97.190.181',NULL,'112.124.12.41','Mozilla/5.0 (compatible; Nmap Scripting Engine; https://nmap.org/book/nse.html)','blocked','dns_redirect','2026-01-22 10:08:42','2026-01-22 10:08:42','2026-01-22 10:08:42'),
(276,'blocked','31.97.190.181',NULL,'112.124.12.41','Mozilla/5.0 (compatible; Nmap Scripting Engine; https://nmap.org/book/nse.html)','blocked','dns_redirect','2026-01-22 10:08:46','2026-01-22 10:08:46','2026-01-22 10:08:46'),
(277,'blocked','31.97.190.181',NULL,'112.124.12.41','Mozilla/5.0 (compatible; Nmap Scripting Engine; https://nmap.org/book/nse.html)','blocked','dns_redirect','2026-01-22 10:08:47','2026-01-22 10:08:47','2026-01-22 10:08:47'),
(278,'blocked','',NULL,'112.124.12.41','','blocked','dns_redirect','2026-01-22 10:09:03','2026-01-22 10:09:03','2026-01-22 10:09:03'),
(279,'blocked','31.97.190.181',NULL,'112.124.12.41','','blocked','dns_redirect','2026-01-22 10:09:04','2026-01-22 10:09:04','2026-01-22 10:09:04'),
(280,'blocked','2a0247805e9dbb1',NULL,'2a06:4883:7000::7d','Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)','blocked','dns_redirect','2026-01-22 10:35:57','2026-01-22 10:35:57','2026-01-22 10:35:57'),
(281,'blocked','2a0247805e9dbb1',NULL,'2a06:4882:9000::b5','Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)','blocked','dns_redirect','2026-01-22 10:36:01','2026-01-22 10:36:01','2026-01-22 10:36:01'),
(282,'blocked','2a0247805e9dbb1',NULL,'2a06:4883:b000::d7','Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)','blocked','dns_redirect','2026-01-22 10:36:01','2026-01-22 10:36:01','2026-01-22 10:36:01'),
(283,'blocked','31.97.190.181',NULL,'188.166.28.34','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-22 14:18:20','2026-01-22 14:18:20','2026-01-22 14:18:20'),
(284,'blocked','31.97.190.181',NULL,'188.166.28.34','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-22 14:18:25','2026-01-22 14:18:25','2026-01-22 14:18:25'),
(285,'blocked','31.97.190.181',NULL,'188.166.28.34','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-22 14:18:26','2026-01-22 14:18:26','2026-01-22 14:18:26'),
(286,'blocked','31.97.190.181',NULL,'188.166.28.34','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-22 14:18:28','2026-01-22 14:18:28','2026-01-22 14:18:28'),
(287,'blocked','31.97.190.181',NULL,'20.240.204.2','Python/3.11 aiohttp/3.8.4','blocked','dns_redirect','2026-01-22 15:12:44','2026-01-22 15:12:44','2026-01-22 15:12:44'),
(288,'blocked','31.97.190.181',NULL,'139.59.28.138','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-22 17:33:56','2026-01-22 17:33:56','2026-01-22 17:33:56'),
(289,'blocked','31.97.190.181',NULL,'20.240.204.2','Python/3.11 aiohttp/3.8.4','blocked','dns_redirect','2026-01-22 17:44:26','2026-01-22 17:44:26','2026-01-22 17:44:26'),
(290,'blocked','31.97.190.181',NULL,'173.249.15.69','libredtail-http','blocked','dns_redirect','2026-01-22 21:02:58','2026-01-22 21:02:58','2026-01-22 21:02:58'),
(291,'blocked','31.97.190.181',NULL,'173.249.15.69','libredtail-http','blocked','dns_redirect','2026-01-22 21:03:01','2026-01-22 21:03:01','2026-01-22 21:03:01'),
(292,'blocked','31.97.190.181',NULL,'173.249.15.69','libredtail-http','blocked','dns_redirect','2026-01-22 21:03:08','2026-01-22 21:03:08','2026-01-22 21:03:08'),
(293,'blocked','31.97.190.181',NULL,'173.249.15.69','libredtail-http','blocked','dns_redirect','2026-01-22 21:03:08','2026-01-22 21:03:08','2026-01-22 21:03:08'),
(294,'blocked','31.97.190.181',NULL,'173.249.15.69','libredtail-http','blocked','dns_redirect','2026-01-22 21:03:08','2026-01-22 21:03:08','2026-01-22 21:03:08'),
(295,'blocked','31.97.190.181',NULL,'173.249.15.69','libredtail-http','blocked','dns_redirect','2026-01-22 21:03:08','2026-01-22 21:03:08','2026-01-22 21:03:08'),
(296,'blocked','31.97.190.181',NULL,'143.198.176.117','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-23 01:00:44','2026-01-23 01:00:44','2026-01-23 01:00:44'),
(297,'blocked','31.97.190.181',NULL,'143.198.176.117','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-23 01:00:49','2026-01-23 01:00:49','2026-01-23 01:00:49'),
(298,'blocked','31.97.190.181',NULL,'143.198.176.117','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-23 01:00:51','2026-01-23 01:00:51','2026-01-23 01:00:51'),
(299,'blocked','31.97.190.181',NULL,'143.198.176.117','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-23 01:00:53','2026-01-23 01:00:53','2026-01-23 01:00:53'),
(300,'blocked','31.97.190.181',NULL,'147.185.133.215','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','blocked','dns_redirect','2026-01-23 01:44:48','2026-01-23 01:44:48','2026-01-23 01:44:48'),
(301,'blocked','2a0247805e9dbb1',NULL,'2a06:4882:b000::be','Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)','blocked','dns_redirect','2026-01-23 04:25:51','2026-01-23 04:25:51','2026-01-23 04:25:51'),
(302,'blocked','2a0247805e9dbb1',NULL,'2a06:4883:5000::5f','Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)','blocked','dns_redirect','2026-01-23 04:25:55','2026-01-23 04:25:55','2026-01-23 04:25:55'),
(303,'blocked','31.97.190.181',NULL,'216.180.246.33','\'Mozilla/5.0 (compatible; GenomeCrawlerd/1.0; +https://www.nokia.com/genomecrawler)\'','blocked','dns_redirect','2026-01-23 06:51:23','2026-01-23 06:51:23','2026-01-23 06:51:23'),
(304,'blocked','31.97.190.181',NULL,'216.180.246.33','\'Mozilla/5.0 (compatible; GenomeCrawlerd/1.0; +https://www.nokia.com/genomecrawler)\'','blocked','dns_redirect','2026-01-23 06:57:46','2026-01-23 06:57:46','2026-01-23 06:57:46'),
(305,'blocked','31.97.190.181',NULL,'216.180.246.33','\'Mozilla/5.0 (compatible; GenomeCrawlerd/1.0; +https://www.nokia.com/genomecrawler)\'','blocked','dns_redirect','2026-01-23 06:58:04','2026-01-23 06:58:04','2026-01-23 06:58:04'),
(306,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::13','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-23 07:53:12','2026-01-23 07:53:12','2026-01-23 07:53:12'),
(307,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::13','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-23 07:57:25','2026-01-23 07:57:25','2026-01-23 07:57:25'),
(308,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::13','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-23 07:57:30','2026-01-23 07:57:30','2026-01-23 07:57:30'),
(309,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::13','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-23 07:57:34','2026-01-23 07:57:34','2026-01-23 07:57:34'),
(310,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::13','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-23 07:57:43','2026-01-23 07:57:43','2026-01-23 07:57:43'),
(311,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::13','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-23 07:57:49','2026-01-23 07:57:49','2026-01-23 07:57:49'),
(312,'blocked','2a0247805e9dbb1',NULL,'2602:80d:1006::13','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-23 07:57:54','2026-01-23 07:57:54','2026-01-23 07:57:54'),
(313,'blocked','31.97.190.181',NULL,'172.237.105.19','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:8.0) Gecko/20100101 Firefox/8.0','blocked','dns_redirect','2026-01-23 08:21:55','2026-01-23 08:21:55','2026-01-23 08:21:55'),
(314,'blocked','31.97.190.181',NULL,'162.142.125.126','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-23 08:40:32','2026-01-23 08:40:32','2026-01-23 08:40:32'),
(315,'blocked','31.97.190.181',NULL,'162.142.125.126','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-23 08:40:38','2026-01-23 08:40:38','2026-01-23 08:40:38'),
(316,'blocked','31.97.190.181',NULL,'162.142.125.126','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-23 08:40:39','2026-01-23 08:40:39','2026-01-23 08:40:39'),
(317,'blocked','31.97.190.181',NULL,'162.142.125.126','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-23 08:40:53','2026-01-23 08:40:53','2026-01-23 08:40:53'),
(318,'blocked','31.97.190.181',NULL,'162.142.125.126','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-23 08:40:54','2026-01-23 08:40:54','2026-01-23 08:40:54'),
(319,'blocked','31.97.190.181',NULL,'162.142.125.126','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-23 08:40:54','2026-01-23 08:40:54','2026-01-23 08:40:54'),
(320,'blocked','31.97.190.181',NULL,'162.142.125.126','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-23 08:40:55','2026-01-23 08:40:55','2026-01-23 08:40:55'),
(321,'blocked','31.97.190.181',NULL,'162.142.125.126','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-23 08:40:56','2026-01-23 08:40:56','2026-01-23 08:40:56'),
(322,'blocked','31.97.190.181',NULL,'162.142.125.126','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-23 08:40:57','2026-01-23 08:40:57','2026-01-23 08:40:57'),
(323,'blocked','31.97.190.181',NULL,'172.237.105.19','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:8.0) Gecko/20100101 Firefox/8.0','blocked','dns_redirect','2026-01-23 10:00:21','2026-01-23 10:00:21','2026-01-23 10:00:21'),
(324,'blocked','31.97.190.181',NULL,'20.240.204.2','Python/3.11 aiohttp/3.8.4','blocked','dns_redirect','2026-01-23 10:35:42','2026-01-23 10:35:42','2026-01-23 10:35:42'),
(325,'blocked','31.97.190.181',NULL,'178.128.232.4','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-23 12:24:09','2026-01-23 12:24:09','2026-01-23 12:24:09'),
(326,'blocked','31.97.190.181',NULL,'178.128.232.4','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-23 12:24:14','2026-01-23 12:24:14','2026-01-23 12:24:14'),
(327,'blocked','31.97.190.181',NULL,'178.128.232.4','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-23 12:24:15','2026-01-23 12:24:15','2026-01-23 12:24:15'),
(328,'blocked','31.97.190.181',NULL,'178.128.232.4','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-23 12:24:17','2026-01-23 12:24:17','2026-01-23 12:24:17'),
(329,'blocked','31.97.190.181',NULL,'20.240.204.2','Python/3.11 aiohttp/3.8.4','blocked','dns_redirect','2026-01-23 16:07:33','2026-01-23 16:07:33','2026-01-23 16:07:33'),
(330,'blocked','31.97.190.181',NULL,'170.64.237.77','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-23 23:42:48','2026-01-23 23:42:48','2026-01-23 23:42:48'),
(331,'blocked','31.97.190.181',NULL,'170.64.237.77','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-23 23:42:52','2026-01-23 23:42:52','2026-01-23 23:42:52'),
(332,'blocked','31.97.190.181',NULL,'170.64.237.77','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-23 23:42:52','2026-01-23 23:42:52','2026-01-23 23:42:52'),
(333,'blocked','31.97.190.181',NULL,'170.64.237.77','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-23 23:42:53','2026-01-23 23:42:53','2026-01-23 23:42:53'),
(334,'blocked','31.97.190.181',NULL,'35.203.210.92','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','blocked','dns_redirect','2026-01-24 03:56:01','2026-01-24 03:56:01','2026-01-24 03:56:01'),
(335,'blocked','31.97.190.181',NULL,'162.216.149.247','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','blocked','dns_redirect','2026-01-24 06:41:52','2026-01-24 06:41:52','2026-01-24 06:41:52'),
(336,'blocked','2a0247805e9dbb1',NULL,'2620:96:e000::118','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-24 08:53:14','2026-01-24 08:53:14','2026-01-24 08:53:14'),
(337,'blocked','2a0247805e9dbb1',NULL,'2620:96:e000::118','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-24 08:53:24','2026-01-24 08:53:24','2026-01-24 08:53:24'),
(338,'blocked','2a0247805e9dbb1',NULL,'2620:96:e000::118','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-24 08:53:26','2026-01-24 08:53:26','2026-01-24 08:53:26'),
(339,'blocked','2a0247805e9dbb1',NULL,'2620:96:e000::118','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-24 08:55:12','2026-01-24 08:55:12','2026-01-24 08:55:12'),
(340,'blocked','2a0247805e9dbb1',NULL,'2620:96:e000::118','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-24 08:55:14','2026-01-24 08:55:14','2026-01-24 08:55:14'),
(341,'blocked','2a0247805e9dbb1',NULL,'2620:96:e000::118','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-24 08:55:16','2026-01-24 08:55:16','2026-01-24 08:55:16'),
(342,'blocked','2a0247805e9dbb1',NULL,'2620:96:e000::118','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-24 08:55:24','2026-01-24 08:55:24','2026-01-24 08:55:24'),
(343,'blocked','2a0247805e9dbb1',NULL,'2620:96:e000::118','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-24 08:55:26','2026-01-24 08:55:26','2026-01-24 08:55:26'),
(344,'blocked','2a0247805e9dbb1',NULL,'2620:96:e000::118','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-24 08:55:28','2026-01-24 08:55:28','2026-01-24 08:55:28'),
(345,'blocked','31.97.190.181',NULL,'167.94.138.116','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-24 09:24:03','2026-01-24 09:24:03','2026-01-24 09:24:03'),
(346,'blocked','31.97.190.181',NULL,'167.94.138.116','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-24 09:24:09','2026-01-24 09:24:09','2026-01-24 09:24:09'),
(347,'blocked','31.97.190.181',NULL,'167.94.138.116','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-24 09:24:09','2026-01-24 09:24:09','2026-01-24 09:24:09'),
(348,'blocked','31.97.190.181',NULL,'167.94.138.116','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-24 09:24:22','2026-01-24 09:24:22','2026-01-24 09:24:22'),
(349,'blocked','31.97.190.181',NULL,'167.94.138.116','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-24 09:24:23','2026-01-24 09:24:23','2026-01-24 09:24:23'),
(350,'blocked','31.97.190.181',NULL,'167.94.138.116','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-24 09:24:24','2026-01-24 09:24:24','2026-01-24 09:24:24'),
(351,'blocked','31.97.190.181',NULL,'167.94.138.116','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-24 09:24:25','2026-01-24 09:24:25','2026-01-24 09:24:25'),
(352,'blocked','31.97.190.181',NULL,'167.94.138.116','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-24 09:24:26','2026-01-24 09:24:26','2026-01-24 09:24:26'),
(353,'blocked','31.97.190.181',NULL,'167.94.138.116','Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)','blocked','dns_redirect','2026-01-24 09:24:28','2026-01-24 09:24:28','2026-01-24 09:24:28'),
(354,'blocked','31.97.190.181',NULL,'129.212.231.109','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-24 10:47:32','2026-01-24 10:47:32','2026-01-24 10:47:32'),
(355,'blocked','31.97.190.181',NULL,'129.212.231.109','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-24 10:47:36','2026-01-24 10:47:36','2026-01-24 10:47:36'),
(356,'blocked','31.97.190.181',NULL,'129.212.231.109','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-24 10:47:37','2026-01-24 10:47:37','2026-01-24 10:47:37'),
(357,'blocked','31.97.190.181',NULL,'129.212.231.109','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36','blocked','dns_redirect','2026-01-24 10:47:37','2026-01-24 10:47:37','2026-01-24 10:47:37'),
(358,'blocked','31.97.190.181',NULL,'20.240.204.2','Python/3.11 aiohttp/3.8.4','blocked','dns_redirect','2026-01-24 10:48:17','2026-01-24 10:48:17','2026-01-24 10:48:17');
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `selector` char(16) NOT NULL,
  `validator_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `consumed_at` datetime DEFAULT NULL,
  `created_ip` varbinary(16) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `selector` (`selector`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES
(2,20,'4724acd766e5c171','85c3bbab044b7e2ca8f92b5c79b821b7f2a231050ac668afcd4a0b00d0389dc0','2025-11-04 23:57:58','2025-11-04 23:51:24',''),
(4,20,'17266610dd773e4e','19cbfe456fe490692c4f2fcf71d25b6bdb5e9402783da607f995707cc8b81613','2025-11-05 01:36:42','2025-11-05 01:17:27','');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `predefined_applications`
--

DROP TABLE IF EXISTS `predefined_applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `predefined_applications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `category_id` int(11) NOT NULL,
  `domains` text NOT NULL,
  `ports` text DEFAULT NULL,
  `protocols` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_app_name` (`name`),
  KEY `category_id` (`category_id`),
  KEY `idx_is_active` (`is_active`),
  CONSTRAINT `fk_predefined_apps_category` FOREIGN KEY (`category_id`) REFERENCES `application_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `predefined_applications`
--

LOCK TABLES `predefined_applications` WRITE;
/*!40000 ALTER TABLE `predefined_applications` DISABLE KEYS */;
INSERT INTO `predefined_applications` VALUES
(1,'Fortnite',1,'fortnite.com,epicgames.com,unrealengine.com','80,443,5222,5223','fortnite','Epic Games Battle Royale','fas fa-gamepad',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(2,'PUBG',1,'pubg.com,krafton.com,battlegrounds.com','7000-7999,8000-8999','pubg','PlayerUnknown\'s Battlegrounds','fas fa-gamepad',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(3,'Minecraft',1,'minecraft.net,mojang.com','25565,25575','minecraft','Sandbox building game','fas fa-cube',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(4,'Roblox',1,'roblox.com,rbxcdn.com','53,80,443','roblox','Online gaming platform','fas fa-gamepad',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(5,'Steam',1,'steampowered.com,steamcommunity.com,steamstatic.com','27000-27100','steam','Gaming platform','fas fa-steam',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(6,'Facebook',2,'facebook.com,fb.com,fbcdn.net','80,443','facebook','Social networking platform','fab fa-facebook',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(7,'Instagram',2,'instagram.com,cdninstagram.com,fbcdn.net','80,443','instagram','Photo and video sharing','fab fa-instagram',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(8,'TikTok',2,'tiktok.com,musically.com,musical.ly,tiktokcdn.com','80,443','tiktok','Short video platform','fab fa-tiktok',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(9,'Twitter',2,'twitter.com,t.co,twimg.com,x.com','80,443','twitter','Social networking and microblogging','fab fa-twitter',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(10,'Snapchat',2,'snapchat.com,sc-cdn.net','80,443','snapchat','Multimedia messaging','fab fa-snapchat',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(11,'YouTube',3,'youtube.com,youtu.be,googlevideo.com,ytimg.com','80,443','youtube','Video sharing platform','fab fa-youtube',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(12,'Netflix',3,'netflix.com,nflxso.net,nflxext.com,nflximg.net','80,443','netflix','Video streaming service','fas fa-film',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(13,'Spotify',3,'spotify.com,scdn.co,spoti.fi','80,443,57621','spotify','Music streaming service','fab fa-spotify',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(14,'Twitch',3,'twitch.tv,twitchcdn.net,jtvnw.net','80,443','twitch','Live streaming platform','fab fa-twitch',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(15,'Disney+',3,'disneyplus.com,disney.com,bamgrid.com','80,443','disney','Disney streaming service','fas fa-film',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(16,'WhatsApp',4,'whatsapp.com,whatsapp.net','443,4244,5222','whatsapp','Messaging application','fab fa-whatsapp',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(17,'Telegram',4,'telegram.org,t.me,telegra.ph','80,443','telegram','Cloud messaging app','fab fa-telegram',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(18,'Discord',4,'discord.com,discordapp.com,discord.gg','80,443,50000-65535','discord','Gaming communication platform','fab fa-discord',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(19,'Zoom',4,'zoom.us,zoom.com','80,443,8801,8802','zoom','Video conferencing','fas fa-video',1,'2025-07-27 16:48:42','2025-07-27 16:48:42'),
(20,'Skype',4,'skype.com,live.com','80,443,1024-65535','skype','Video calling service','fab fa-skype',1,'2025-07-27 16:48:42','2025-07-27 16:48:42');
/*!40000 ALTER TABLE `predefined_applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recent_activity_cache`
--

DROP TABLE IF EXISTS `recent_activity_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recent_activity_cache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mac_address` varchar(17) NOT NULL,
  `recent_sites` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`recent_sites`)),
  `recent_apps` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`recent_apps`)),
  `bandwidth_usage` varchar(20) DEFAULT NULL,
  `connections` int(11) DEFAULT NULL,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_mac` (`mac_address`),
  KEY `idx_updated` (`last_updated`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recent_activity_cache`
--

LOCK TABLES `recent_activity_cache` WRITE;
/*!40000 ALTER TABLE `recent_activity_cache` DISABLE KEYS */;
INSERT INTO `recent_activity_cache` VALUES
(1,'9A:C1:84:DA:8F:22','[]','[]','N/A',0,'2025-08-25 06:33:22'),
(2,'98:8F:E0:71:C4:3D','[]','[]','N/A',0,'2025-08-25 06:33:22'),
(3,'9A:C1:84:DA:8F:22','[]','[]','N/A',0,'2025-08-25 06:36:13'),
(4,'98:8F:E0:71:C4:3D','[]','[]','N/A',0,'2025-08-25 06:36:14'),
(5,'9A:C1:84:DA:8F:22','[]','[]','N/A',0,'2025-08-25 06:41:23'),
(6,'98:8F:E0:71:C4:3D','[]','[]','N/A',0,'2025-08-25 06:41:24'),
(7,'9A:C1:84:DA:8F:22','[]','[]','N/A',0,'2025-08-25 06:41:35'),
(8,'98:8F:E0:71:C4:3D','[]','[]','N/A',0,'2025-08-25 06:41:36'),
(9,'9A:C1:84:DA:8F:22','[]','[]','N/A',0,'2025-08-25 06:42:43'),
(10,'98:8F:E0:71:C4:3D','[]','[]','N/A',0,'2025-08-25 06:42:43'),
(11,'9A:C1:84:DA:8F:22','[]','[]','N/A',0,'2025-08-25 06:42:58'),
(12,'98:8F:E0:71:C4:3D','[]','[]','N/A',0,'2025-08-25 06:42:59'),
(13,'9A:C1:84:DA:8F:22','[]','[]','N/A',0,'2025-08-25 06:43:15'),
(14,'98:8F:E0:71:C4:3D','[]','[]','N/A',0,'2025-08-25 06:43:15'),
(15,'9A:C1:84:DA:8F:22','[]','[]','N/A',0,'2025-08-25 07:32:46');
/*!40000 ALTER TABLE `recent_activity_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `plan` enum('free','premium') NOT NULL DEFAULT 'free',
  `status` enum('active','pending','inactive','canceled','expired') NOT NULL DEFAULT 'active',
  `order_id` varchar(64) DEFAULT NULL,
  `started_at` datetime NOT NULL DEFAULT current_timestamp(),
  `expires_at` datetime DEFAULT NULL,
  `canceled_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_expires` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
INSERT INTO `subscriptions` VALUES
(1,3,'premium','active','9W912126DN742270R','2025-10-28 06:09:09','2025-11-27 06:09:09',NULL,'2025-10-28 06:09:09'),
(12,2,'free','inactive',NULL,'2025-10-09 09:58:26',NULL,'2025-10-09 09:59:09','2025-10-09 09:59:09'),
(18,9,'premium','active','0FX71058SB265062F','2025-10-22 13:35:25','2025-11-22 13:35:25',NULL,'2025-10-22 13:35:25'),
(24,23,'premium','active',NULL,'2025-10-27 11:01:58','2025-11-26 11:01:58',NULL,'2025-10-27 11:01:58'),
(28,25,'free','inactive',NULL,'2025-11-04 16:45:02',NULL,'2025-11-04 16:45:05','2025-11-04 16:45:05'),
(30,27,'premium','active',NULL,'2025-11-04 23:17:21','2025-12-04 23:17:21','2025-11-04 23:17:19','2025-11-04 23:17:21'),
(39,22,'premium','active',NULL,'2026-01-17 16:46:37','2026-02-16 16:46:37',NULL,'2026-01-17 16:46:37'),
(40,26,'premium','active',NULL,'2026-01-20 13:11:44','2026-02-19 13:11:44',NULL,'2026-01-20 13:11:44');
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_activity_log`
--

DROP TABLE IF EXISTS `user_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `activity_type` varchar(50) DEFAULT NULL,
  `connections` int(11) DEFAULT 0,
  `protocols` text DEFAULT NULL,
  `ports` text DEFAULT NULL,
  `logged_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ip_time` (`ip_address`,`logged_at`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_activity_log`
--

LOCK TABLES `user_activity_log` WRITE;
/*!40000 ALTER TABLE `user_activity_log` DISABLE KEYS */;
INSERT INTO `user_activity_log` VALUES
(1,'192.168.10.253','Unknown',0,'[]','[]','2025-08-22 16:39:13'),
(2,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 13:31:32'),
(3,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 13:32:09'),
(4,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 13:37:34'),
(5,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 14:18:00'),
(6,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 14:28:57'),
(7,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 14:53:31'),
(8,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 14:57:11'),
(9,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 14:58:48'),
(10,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 15:36:34'),
(11,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 15:42:44'),
(12,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 15:46:14'),
(13,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 15:47:10'),
(14,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 15:49:40'),
(15,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 15:53:47'),
(16,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:01:17'),
(17,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:03:57'),
(18,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:06:13'),
(19,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:08:45'),
(20,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:08:55'),
(21,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:09:57'),
(22,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:14:07'),
(23,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:21:22'),
(24,'192.168.10.251','Unknown',0,'[]','[]','2025-08-24 16:21:22'),
(25,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:22:32'),
(26,'192.168.10.251','Unknown',0,'[]','[]','2025-08-24 16:22:33'),
(27,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:24:47'),
(28,'192.168.10.251','Unknown',0,'[]','[]','2025-08-24 16:24:47'),
(29,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:25:47'),
(30,'192.168.10.251','Unknown',0,'[]','[]','2025-08-24 16:25:47'),
(31,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:26:54'),
(32,'192.168.10.251','Unknown',0,'[]','[]','2025-08-24 16:26:55'),
(33,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:27:55'),
(34,'192.168.10.251','Unknown',0,'[]','[]','2025-08-24 16:27:55'),
(35,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:28:53'),
(36,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:29:55'),
(37,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:30:55'),
(38,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:31:07'),
(39,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:34:03'),
(40,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:39:04'),
(41,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:42:58'),
(42,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:46:05'),
(43,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:46:33'),
(44,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:52:01'),
(45,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:57:33'),
(46,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 16:58:19'),
(47,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 17:00:05'),
(48,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:09:14'),
(49,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:09:40'),
(50,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:09:50'),
(51,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:10:18'),
(52,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:10:22'),
(53,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:10:31'),
(54,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:10:42'),
(55,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:10:52'),
(56,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:11:02'),
(57,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:11:12'),
(58,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:11:22'),
(59,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:11:32'),
(60,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:11:42'),
(61,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:11:52'),
(62,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:12:02'),
(63,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:12:12'),
(64,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:12:22'),
(65,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:12:32'),
(66,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:12:42'),
(67,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:12:53'),
(68,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:13:02'),
(69,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:13:12'),
(70,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:13:22'),
(71,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:13:32'),
(72,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:13:42'),
(73,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:13:51'),
(74,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:14:01'),
(75,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:14:12'),
(76,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:14:22'),
(77,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:14:32'),
(78,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:14:42'),
(79,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:14:51'),
(80,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:15:02'),
(81,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:15:12'),
(82,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:15:22'),
(83,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:15:32'),
(84,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:15:41'),
(85,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:15:52'),
(86,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:16:01'),
(87,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:16:12'),
(88,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:16:22'),
(89,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:16:32'),
(90,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:16:41'),
(91,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:16:51'),
(92,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:17:01'),
(93,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:17:12'),
(94,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:17:22'),
(95,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:17:31'),
(96,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:17:42'),
(97,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:17:52'),
(98,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:18:01'),
(99,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:18:12'),
(100,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:18:22'),
(101,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:18:32'),
(102,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:18:42'),
(103,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:18:52'),
(104,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:19:02'),
(105,'192.168.10.252','Unknown',0,'[]','[]','2025-08-24 18:19:12');
/*!40000 ALTER TABLE `user_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `whitelist`
--

DROP TABLE IF EXISTS `whitelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `whitelist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `website` text DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `added_by` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`) USING BTREE,
  KEY `category` (`category`),
  KEY `added_by` (`added_by`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `whitelist`
--

LOCK TABLES `whitelist` WRITE;
/*!40000 ALTER TABLE `whitelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `whitelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'mysite_db'
--

--
-- Dumping routines for database 'mysite_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-24 12:41:26
